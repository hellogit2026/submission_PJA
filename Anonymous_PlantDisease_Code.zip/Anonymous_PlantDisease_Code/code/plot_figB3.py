import os
# -*- coding: utf-8 -*-
"""
Figure B3: Hallucination predictions under basic augmentation,
strong augmentation, and DANN (mean ± range over three seeds).
"""
import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

BASE = os.path.join(ROOT_DIR, "results", "cross_domain_detailed")

basic_files = [f"{BASE}/source_only_seed{s}/confusion_matrix.json" for s in (42, 123, 456)]
strong_files = [f"{BASE}/source_only_strong_seed{s}/confusion_matrix.json" for s in (42, 123, 456)]
dann_files   = [f"{BASE}/dann_seed{s}/confusion_matrix.json" for s in (42, 123, 456)]

ghost_indices = [1, 5, 10, 12, 13, 15, 16, 22, 26, 34]
ghost_names = [
    "Apple_Black_rot", "Cherry_Powdery_mildew", "Corn_healthy",
    "Grape_Esca", "Grape_Leaf_blight", "Orange_Huanglongbing",
    "Peach_Bacterial_spot", "Potato_healthy", "Strawberry_Leaf_scorch",
    "Tomato_Target_Spot",
]

def extract_ghost_counts(path):
    with open(path, "r", encoding="utf-8") as f:
        m = json.load(f)["matrix"]
    return [sum(m[r][gi] for r in range(38)) for gi in ghost_indices]

def summarise(files):
    runs = np.array([extract_ghost_counts(p) for p in files], dtype=float)
    return runs.mean(0), runs.min(0), runs.max(0)

b_mean, b_min, b_max = summarise(basic_files)
s_mean, s_min, s_max = summarise(strong_files)
d_mean, d_min, d_max = summarise(dann_files)

x = np.arange(len(ghost_names)); width = 0.25
fig, ax = plt.subplots(figsize=(15, 6))

def draw(xpos, mean, lo, hi, label, color):
    # draw bars and error bars
    ax.bar(xpos, mean, width, label=label, color=color, alpha=0.85,
           yerr=np.array([mean - lo, hi - mean]), capsize=4,
           error_kw={"elinewidth": 1.2, "capthick": 1.2})
    
    # place labels above the error-bar top (hi), not at the mean
    for xp, m, top in zip(xpos, mean, hi):
        if m > 0.3:
            ax.annotate(f"{m:.1f}", xy=(xp, top), xytext=(0, 4),
                        textcoords="offset points", ha="center",
                        va="bottom", fontsize=8, color=color, fontweight='bold')

draw(x - width, b_mean, b_min, b_max, "Source Only (basic)",  "steelblue")
draw(x,         s_mean, s_min, s_max, "Source Only (strong)", "seagreen")
draw(x + width, d_mean, d_min, d_max, "DANN (strong)",        "coral")

ax.set_xlabel("Ghost class", fontsize=12)
ax.set_ylabel("Hallucination predictions (mean ± range)", fontsize=12)
ax.set_title("Figure B3. Hallucination predictions under basic augmentation, "
             "strong augmentation, and DANN (mean ± range over 3 seeds)", fontsize=13)
ax.set_xticks(x)
ax.set_xticklabels(ghost_names, rotation=40, ha="right", fontsize=9)
ax.legend(fontsize=10, loc='upper left', bbox_to_anchor=(0.01, 0.98))
ax.grid(axis="y", linestyle=":", alpha=0.4)

# move the annotation to the upper left to avoid overlap with the Strawberry label
ax.text(0.01, 0.90, "Strawberry_Leaf_scorch dominates; see Table B3 for per-class values.",
        transform=ax.transAxes, ha="left", va="top", fontsize=8, color="dimgray")

# add headroom at the top of the y-axis so the highest label does not touch the title
ax.set_ylim(0, ax.get_ylim()[1] * 1.15)

plt.tight_layout()
OUT = os.path.join(ROOT_DIR, "results", "figB3")
plt.savefig(f"{OUT}_3groups.png", dpi=300)
plt.savefig(f"{OUT}_3groups.pdf")
print(f"[Saved] {OUT}_3groups.png / .pdf")

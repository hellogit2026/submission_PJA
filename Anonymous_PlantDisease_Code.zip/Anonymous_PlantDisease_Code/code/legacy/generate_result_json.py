"""
generate_result_json.py
# regenerate result.json for seed_456
# load the existing best_model.pth, run test-set inference, write the result file
# no retraining needed
"""

import os
import json
import time
import warnings

import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from torchvision import models, transforms
from torchvision.datasets import ImageFolder
ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

warnings.filterwarnings("ignore")

# ==================== configuration (same as repeat_experiment.py)====================
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
NUM_CLASSES = 38
BATCH_SIZE = 32

DATA_ROOT = os.path.join(ROOT_DIR, "data", "plantvillage_split")
TRAIN_DIR = os.path.join(DATA_ROOT, "train")
VAL_DIR = os.path.join(DATA_ROOT, "val")
TEST_DIR = os.path.join(DATA_ROOT, "test")

SEED = 7
MODEL_PATH = os.path.join(ROOT_DIR, "results", "repeat_experiment", "seed_7", "best_model.pth")
OUTPUT_DIR = os.path.join(ROOT_DIR, "results", "repeat_experiment", "seed_7")

# ==================== data transforms ====================
def get_transforms():
    train_transform = transforms.Compose([
        transforms.RandomResizedCrop(224, scale=(0.08, 1.0)),
        transforms.RandomHorizontalFlip(p=0.5),
        transforms.RandomVerticalFlip(p=0.3),
        transforms.RandomRotation(degrees=30),
        transforms.ColorJitter(brightness=0.4, contrast=0.4, saturation=0.4, hue=0.1),
        transforms.RandomAffine(degrees=0, translate=(0.1, 0.1), scale=(0.9, 1.1)),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406],
                             std=[0.229, 0.224, 0.225])
    ])
    val_transform = transforms.Compose([
        transforms.Resize(256),
        transforms.CenterCrop(224),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406],
                             std=[0.229, 0.224, 0.225])
    ])
    return train_transform, val_transform

# ==================== model ====================
def create_model(num_classes=38, pretrained=False):
    model = models.mobilenet_v2(weights=None)
    model.classifier[1] = nn.Linear(model.classifier[1].in_features, num_classes)
    return model

# ==================== evaluation ====================
@torch.no_grad()
def evaluate(model, dataloader, criterion, device):
    model.eval()
    running_loss = 0.0
    correct = 0
    total = 0

    for batch_idx, (inputs, labels) in enumerate(dataloader):
        inputs, labels = inputs.to(device), labels.to(device)
        outputs = model(inputs)
        loss = criterion(outputs, labels)

        running_loss += loss.item() * inputs.size(0)
        _, predicted = outputs.max(1)
        total += labels.size(0)
        correct += predicted.eq(labels).sum().item()

        if (batch_idx + 1) % 50 == 0:
            print(f"  [Eval] Batch {batch_idx+1}/{len(dataloader)} done")

    epoch_loss = running_loss / total
    epoch_acc = 100.0 * correct / total
    return epoch_loss, epoch_acc

# ==================== main pipeline ====================
def main():
    print(f"{'='*60}")
    print(f"regenerating result.json for seed_{SEED}")
    print(f"{'='*60}")

    # check model file
    if not os.path.exists(MODEL_PATH):
        print(f"[ERROR] model file not found: {MODEL_PATH}")
        return

    print(f"[Info] model path: {MODEL_PATH}")
    print(f"[Info] model size: {os.path.getsize(MODEL_PATH) / 1024 / 1024:.1f} MB")

    # loading data
    print(f"[Info] loading dataset...")
    train_transform, val_transform = get_transforms()

    train_dataset = ImageFolder(TRAIN_DIR, transform=train_transform)
    val_dataset = ImageFolder(VAL_DIR, transform=val_transform)
    test_dataset = ImageFolder(TEST_DIR, transform=val_transform)

    print(f"  train set: {len(train_dataset)}  ")
    print(f"  val set: {len(val_dataset)}  ")
    print(f"  test set: {len(test_dataset)}  ")

    train_loader = DataLoader(train_dataset, batch_size=BATCH_SIZE, shuffle=False,
                               num_workers=0, pin_memory=False)
    val_loader = DataLoader(val_dataset, batch_size=BATCH_SIZE, shuffle=False,
                             num_workers=0, pin_memory=False)
    test_loader = DataLoader(test_dataset, batch_size=BATCH_SIZE, shuffle=False,
                              num_workers=0, pin_memory=False)

    # Loading model
    print(f"[Info] Loading model...")
    model = create_model(num_classes=NUM_CLASSES, pretrained=False).to(DEVICE)
    checkpoint = torch.load(MODEL_PATH, map_location=DEVICE)

    # compatible with both formats
    if isinstance(checkpoint, dict) and 'model_state_dict' in checkpoint:
        model.load_state_dict(checkpoint['model_state_dict'])
        best_acc = checkpoint.get('best_acc', 0.0)
    else:
        model.load_state_dict(checkpoint)
        best_acc = 0.0  # best_acc unavailable from a plain state_dict

    print(f"[Info] model moved to {DEVICE}")

    # evaluation
    criterion = nn.CrossEntropyLoss()

    print(f"[Info] evaluating on the val set...")
    val_loss, val_acc = evaluate(model, val_loader, criterion, DEVICE)
    print(f"[Result] val set: Loss={val_loss:.4f}, Acc={val_acc:.4f}%")

    print(f"[Info] evaluating on the test set...")
    test_loss, test_acc = evaluate(model, test_loader, criterion, DEVICE)
    print(f"[Result] test set: Loss={test_loss:.4f}, Acc={test_acc:.4f}%")

    # generate result.json
    # no training history; history filled with empty lists
    result = {
        "seed": SEED,
        "best_val_acc": val_acc,
        "test_acc": test_acc,
        "epochs": 0,  # actual epoch count unavailable
        "history": {
            "train_loss": [],
            "train_acc": [],
            "val_loss": [],
            "val_acc": [],
            "test_acc": test_acc,
            "lr": [],
            "epoch_times": []
        },
        "config": {
            "model": "mobilenet_v2",
            "batch_size": 32,
            "lr": 5e-05,
            "weight_decay": 0.001,
            "warmup_epochs": 10,
            "max_epochs": 80,
            "patience": 7
        }
    }

    json_path = os.path.join(OUTPUT_DIR, "result.json")
    with open(json_path, 'w', encoding='utf-8') as f:
        json.dump(result, f, indent=2, ensure_ascii=False)

    print(f"\n[Saved] result.json saved: {json_path}")
    print(f"[Summary] seed={SEED} | Val Acc={val_acc:.4f}% | Test Acc={test_acc:.4f}%")

if __name__ == "__main__":
    main()
"""
repeat_experiment.py
Repeat experiment (multiple seeds) - full script
Fixes: corrupted-data detection, per-batch debugging, single-process loading, forced PIL backend
"""

import os
import sys
import time
import json
import random
import argparse
import warnings
import traceback
from datetime import datetime
from PIL import Image

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, Dataset
from torchvision import models, transforms
from torchvision.datasets import ImageFolder
from torch.optim.lr_scheduler import CosineAnnealingLR
ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# force the PIL backend to avoid torchvision C++ extension issues
Image.MAX_IMAGE_PIXELS = None
warnings.filterwarnings("ignore", category=UserWarning)

# ==================== configuration ====================
SEEDS = [42, 123, 456]
MODEL_NAME = "mobilenet_v2"
NUM_CLASSES = 38
BATCH_SIZE = 32
LEARNING_RATE = 5e-5
WEIGHT_DECAY = 1e-3
NUM_EPOCHS = 80
WARMUP_EPOCHS = 10
PATIENCE = 7
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# datapath
DATA_ROOT = os.path.join(ROOT_DIR, "data", "plantvillage_split")
TRAIN_DIR = os.path.join(DATA_ROOT, "train")
VAL_DIR = os.path.join(DATA_ROOT, "val")
TEST_DIR = os.path.join(DATA_ROOT, "test")
OUTPUT_DIR = os.path.join(ROOT_DIR, "results", "repeat_experiment")

# ==================== safe dataset class ====================
class SafeImageFolder(ImageFolder):
    """ImageFolder that skips corrupted images"""
    def __getitem__(self, index):
        """
        Args:
            index (int): Index
        Returns:
            tuple: (sample, target) where target is class_index of the target class.
        """
        path, target = self.samples[index]
        try:
            sample = self.loader(path)
        except Exception as e:
            print(f"    [WARN] skipping corrupted image: {path} ({str(e)})")
            # return a blank image instead
            sample = Image.new('RGB', (224, 224), (128, 128, 128))
        if self.transform is not None:
            sample = self.transform(sample)
        if self.target_transform is not None:
            target = self.target_transform(target)
        return sample, target

# ==================== data augmentation ====================
def get_transforms(aug_type="strong"):
    if aug_type == "strong":
        train_transform = transforms.Compose([
            transforms.RandomResizedCrop(224, scale=(0.08, 1.0)),
            transforms.RandomHorizontalFlip(p=0.5),
            transforms.RandomVerticalFlip(p=0.3),
            transforms.RandomRotation(degrees=30),
            transforms.ColorJitter(brightness=0.4, contrast=0.4, saturation=0.4, hue=0.1),
            transforms.RandomAffine(degrees=0, translate=(0.1, 0.1), scale=(0.9, 1.1)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                 std=[0.229, 0.224, 0.225])
        ])
    else:
        train_transform = transforms.Compose([
            transforms.RandomResizedCrop(224),
            transforms.RandomHorizontalFlip(),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                 std=[0.229, 0.224, 0.225])
        ])

    val_transform = transforms.Compose([
        transforms.Resize(256),
        transforms.CenterCrop(224),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406],
                             std=[0.229, 0.224, 0.225])
    ])
    return train_transform, val_transform

# ==================== model ====================
def create_model(num_classes=38, pretrained=True):
    model = models.mobilenet_v2(weights="IMAGENET1K_V1" if pretrained else None)
    model.classifier[1] = nn.Linear(model.classifier[1].in_features, num_classes)
    return model

# ==================== warm-up scheduler ====================
class WarmupCosineScheduler:
    def __init__(self, optimizer, warmup_epochs, total_epochs, min_lr=1e-6):
        self.optimizer = optimizer
        self.warmup_epochs = warmup_epochs
        self.total_epochs = total_epochs
        self.min_lr = min_lr
        self.base_lr = optimizer.param_groups[0]['lr']
        self.cosine_scheduler = CosineAnnealingLR(
            optimizer, T_max=total_epochs - warmup_epochs, eta_min=min_lr
        )
        self.current_epoch = 0

    def step(self):
        self.current_epoch += 1
        if self.current_epoch <= self.warmup_epochs:
            lr = self.base_lr * (self.current_epoch / self.warmup_epochs)
            for param_group in self.optimizer.param_groups:
                param_group['lr'] = lr
        else:
            self.cosine_scheduler.step()

    def get_lr(self):
        return self.optimizer.param_groups[0]['lr']

    def state_dict(self):
        return {
            'current_epoch': self.current_epoch,
            'cosine_scheduler': self.cosine_scheduler.state_dict()
        }

    def load_state_dict(self, state_dict):
        self.current_epoch = state_dict['current_epoch']
        self.cosine_scheduler.load_state_dict(state_dict['cosine_scheduler'])

# ==================== train and validation ====================
def train_one_epoch(model, dataloader, criterion, optimizer, device, epoch_idx):
    model.train()
    running_loss = 0.0
    correct = 0
    total = 0
    batch_count = len(dataloader)

    print(f"    [Epoch {epoch_idx}] training started, {batch_count} batches ...")

    for batch_idx, (inputs, labels) in enumerate(dataloader):
        # print confirmation for the first batch
        if batch_idx == 0:
            print(f"    [Epoch {epoch_idx}] first batch loaded OK, shape={inputs.shape}")

        inputs, labels = inputs.to(device), labels.to(device)

        optimizer.zero_grad()
        outputs = model(inputs)
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()

        running_loss += loss.item() * inputs.size(0)
        _, predicted = outputs.max(1)
        total += labels.size(0)
        correct += predicted.eq(labels).sum().item()

        # progress print every 50 batches
        if (batch_idx + 1) % 50 == 0 or batch_idx == batch_count - 1:
            print(f"    [Epoch {epoch_idx}] Batch {batch_idx+1}/{batch_count} done")

    epoch_loss = running_loss / total
    epoch_acc = 100.0 * correct / total
    print(f"    [Epoch {epoch_idx}] training done: Loss={epoch_loss:.4f}, Acc={epoch_acc:.2f}%")
    return epoch_loss, epoch_acc

@torch.no_grad()
def evaluate(model, dataloader, criterion, device, desc="val"):
    model.eval()
    running_loss = 0.0
    correct = 0
    total = 0

    print(f"    [{desc}] Evaluating...")
    for batch_idx, (inputs, labels) in enumerate(dataloader):
        inputs, labels = inputs.to(device), labels.to(device)
        outputs = model(inputs)
        loss = criterion(outputs, labels)

        running_loss += loss.item() * inputs.size(0)
        _, predicted = outputs.max(1)
        total += labels.size(0)
        correct += predicted.eq(labels).sum().item()

    epoch_loss = running_loss / total
    epoch_acc = 100.0 * correct / total
    print(f"    [{desc}] evaluation done: Loss={epoch_loss:.4f}, Acc={epoch_acc:.2f}%")
    return epoch_loss, epoch_acc

# ==================== checkpoint-resume management ====================
def save_checkpoint(state, checkpoint_dir, is_best=False):
    os.makedirs(checkpoint_dir, exist_ok=True)
    checkpoint_path = os.path.join(checkpoint_dir, "checkpoint.pth")
    torch.save(state, checkpoint_path)
    if is_best:
        best_path = os.path.join(checkpoint_dir, "best_model.pth")
        torch.save(state, best_path)
        print(f"[Checkpoint] Best model saved: {best_path}")
    print(f"[Checkpoint] Checkpoint saved: {checkpoint_path}")

def load_checkpoint(checkpoint_dir, model, optimizer, scheduler):
    checkpoint_path = os.path.join(checkpoint_dir, "checkpoint.pth")
    if not os.path.exists(checkpoint_path):
        print(f"[Checkpoint] No checkpoint found; starting from scratch: {checkpoint_path}")
        return 0, 0.0, {}, 0

    print(f"[Checkpoint] resuming from {checkpoint_path} ...")
    checkpoint = torch.load(checkpoint_path, map_location=DEVICE)

    model.load_state_dict(checkpoint['model_state_dict'])
    optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
    scheduler.load_state_dict(checkpoint['scheduler_state_dict'])

    start_epoch = checkpoint['epoch'] + 1
    best_acc = checkpoint['best_acc']
    history = checkpoint.get('history', {})
    patience_counter = checkpoint.get('patience_counter', 0)

    print(f"[Checkpoint] resume: epoch={start_epoch}, best_acc={best_acc:.4f}%")
    return start_epoch, best_acc, history, patience_counter

# ==================== data warm-up check ====================
def warmup_check(dataloader, name="dataset"):
    """warm-up: load the first batch to verify the data"""
    print(f"[Warmup] Warming up {name}...")
    try:
        for batch_idx, (inputs, labels) in enumerate(dataloader):
            print(f"[Warmup] [OK] {name} first batch loaded OK: inputs={inputs.shape}, labels={labels.shape}")
            break
    except Exception as e:
        print(f"[Warmup] [FAIL] {name} failed to load: {str(e)}")
        traceback.print_exc()
        raise

# ==================== main experiment pipeline ====================
def run_experiment(seed, output_dir, resume=True):
    print(f"\n{'='*60}")
    print(f"Starting experiment: seed={seed}")
    print(f"{'='*60}")

    random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)

    exp_dir = os.path.join(output_dir, f"seed_{seed}")
    os.makedirs(exp_dir, exist_ok=True)
    print(f"[Info] Output directory: {exp_dir}")

    # Checking data paths
    print(f"[Info] Checking data paths...")
    for d in [TRAIN_DIR, VAL_DIR, TEST_DIR]:
        if not os.path.exists(d):
            print(f"[ERROR] Path not found: {d}")
            return None
        else:
            num_files = sum(1 for _ in os.walk(d) for _ in _[2])
            print(f"  [OK] {os.path.basename(d)}: {num_files}  images")

    # data loading (SafeImageFolder skips corrupted images)
    print(f"[Info] Loading datasets...")
    train_transform, val_transform = get_transforms("strong")

    print(f"  Loading train set...")
    train_dataset = SafeImageFolder(TRAIN_DIR, transform=train_transform)
    print(f"  [OK] train set: {len(train_dataset)}  , {len(train_dataset.classes)} classes")

    print(f"  Loading val set...")
    val_dataset = SafeImageFolder(VAL_DIR, transform=val_transform)
    print(f"  [OK] val set: {len(val_dataset)}  ")

    print(f"  Loading test set...")
    test_dataset = SafeImageFolder(TEST_DIR, transform=val_transform)
    print(f"  [OK] test set: {len(test_dataset)}  ")

    # DataLoader: num_workers=0 to avoid deadlock
    train_loader = DataLoader(train_dataset, batch_size=BATCH_SIZE, shuffle=True,
                               num_workers=0, pin_memory=False)
    val_loader = DataLoader(val_dataset, batch_size=BATCH_SIZE, shuffle=False,
                             num_workers=0, pin_memory=False)
    test_loader = DataLoader(test_dataset, batch_size=BATCH_SIZE, shuffle=False,
                              num_workers=0, pin_memory=False)
    print(f"[Info] DataLoaders ready")

    # warm-up: load one batch first to verify
    warmup_check(train_loader, "train set")
    warmup_check(val_loader, "val set")
    warmup_check(test_loader, "test set")

    # model, loss, optimizer
    print(f"[Info] Initializing model...")
    model = create_model(num_classes=NUM_CLASSES, pretrained=True).to(DEVICE)
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.AdamW(model.parameters(), lr=LEARNING_RATE, weight_decay=WEIGHT_DECAY)
    scheduler = WarmupCosineScheduler(optimizer, warmup_epochs=WARMUP_EPOCHS, total_epochs=NUM_EPOCHS)
    print(f"[Info] model moved to {DEVICE}")

    # try checkpoint resume
    start_epoch = 0
    best_acc = 0.0
    history = {
        'train_loss': [], 'train_acc': [],
        'val_loss': [], 'val_acc': [],
        'test_acc': None,
        'lr': [], 'epoch_times': []
    }
    patience_counter = 0

    if resume:
        start_epoch, best_acc, loaded_history, patience_counter = load_checkpoint(exp_dir, model, optimizer, scheduler)
        if start_epoch > 0:
            history = loaded_history

    # training loop
    print(f"[Info] === training start: epoch {start_epoch+1} -> {NUM_EPOCHS} ===")
    for epoch in range(start_epoch, NUM_EPOCHS):
        epoch_start = time.time()
        print(f"\n[Epoch {epoch+1}/{NUM_EPOCHS}] start...")

        train_loss, train_acc = train_one_epoch(model, train_loader, criterion, optimizer, DEVICE, epoch+1)
        val_loss, val_acc = evaluate(model, val_loader, criterion, DEVICE, desc="val")
        scheduler.step()

        epoch_time = time.time() - epoch_start
        current_lr = scheduler.get_lr()

        history['train_loss'].append(train_loss)
        history['train_acc'].append(train_acc)
        history['val_loss'].append(val_loss)
        history['val_acc'].append(val_acc)
        history['lr'].append(current_lr)
        history['epoch_times'].append(epoch_time)

        print(f"[Epoch {epoch+1:02d}/{NUM_EPOCHS}] "
              f"Train Loss: {train_loss:.4f} | Train Acc: {train_acc:.2f}% | "
              f"Val Loss: {val_loss:.4f} | Val Acc: {val_acc:.2f}% | "
              f"LR: {current_lr:.6f} | Time: {epoch_time:.1f}s")

        is_best = val_acc > best_acc
        if is_best:
            best_acc = val_acc
            patience_counter = 0
            print(f"  >>> New best validation accuracy: {best_acc:.4f}%")
        else:
            patience_counter += 1

        checkpoint_state = {
            'epoch': epoch,
            'model_state_dict': model.state_dict(),
            'optimizer_state_dict': optimizer.state_dict(),
            'scheduler_state_dict': scheduler.state_dict(),
            'best_acc': best_acc,
            'history': history,
            'patience_counter': patience_counter,
            'seed': seed
        }
        save_checkpoint(checkpoint_state, exp_dir, is_best=is_best)

        if patience_counter >= PATIENCE:
            print(f"[Early Stop] no improvement for {PATIENCE} epochs; early stopping.")
            break
    # training finished; clean up the checkpoint file
    checkpoint_path = os.path.join(exp_dir, "checkpoint.pth")
    if os.path.exists(checkpoint_path):
        os.remove(checkpoint_path)
        print(f"[Cleanup] Checkpoint file removed: {checkpoint_path}")

    # loadbestmodeltest
    print(f"[Info] Loading best model for testing...")
    best_model_path = os.path.join(exp_dir, "best_model.pth")
    if os.path.exists(best_model_path):
        checkpoint = torch.load(best_model_path, map_location=DEVICE)
        model.load_state_dict(checkpoint['model_state_dict'])
        print(f"  [OK] Best model loaded")
    else:
        print(f"  ! best checkpoint not found; using current weights")

    test_loss, test_acc = evaluate(model, test_loader, criterion, DEVICE, desc="test")
    history['test_acc'] = test_acc
    print(f"\n[Result] seed={seed} | Best Val: {best_acc:.4f}% | Test: {test_acc:.4f}%")

    result = {
        'seed': seed,
        'best_val_acc': best_acc,
        'test_acc': test_acc,
        'epochs': len(history['train_acc']),
        'history': history,
        'config': {
            'model': MODEL_NAME,
            'batch_size': BATCH_SIZE,
            'lr': LEARNING_RATE,
            'weight_decay': WEIGHT_DECAY,
            'warmup_epochs': WARMUP_EPOCHS,
            'max_epochs': NUM_EPOCHS,
            'patience': PATIENCE
        }
    }

    json_path = os.path.join(exp_dir, "result.json")
    with open(json_path, 'w', encoding='utf-8') as f:
        json.dump(result, f, indent=2, ensure_ascii=False)
    print(f"[Saved] Results saved: {json_path}")

    return result

# ==================== summary ====================
def generate_summary(output_dir):
    all_results = []
    for seed in SEEDS:
        json_path = os.path.join(output_dir, f"seed_{seed}", "result.json")
        if os.path.exists(json_path):
            with open(json_path, 'r') as f:
                result = json.load(f)
            all_results.append(result)

    if not all_results:
        print("[Warning] No results found")
        return

    print(f"\n{'='*60}")
    print("repeat-experiment summary report")
    print(f"{'='*60}")

    val_accs = [r['best_val_acc'] for r in all_results]
    test_accs = [r['test_acc'] for r in all_results]

    import statistics
    print(f"\nValidation accuracy:")
    for r in all_results:
        print(f"  seed={r['seed']:3d}: {r['best_val_acc']:.4f}%")
    print(f"  Mean: {statistics.mean(val_accs):.4f}% ± {statistics.stdev(val_accs):.4f}%")

    print(f"\nTest accuracy:")
    for r in all_results:
        print(f"  seed={r['seed']:3d}: {r['test_acc']:.4f}%")
    print(f"  Mean: {statistics.mean(test_accs):.4f}% ± {statistics.stdev(test_accs):.4f}%")

    summary = {
        'experiment': 'repeat_experiment_mobilenetv2_strong',
        'seeds': SEEDS,
        'results': all_results,
        'summary': {
            'val_acc_mean': statistics.mean(val_accs),
            'val_acc_std': statistics.stdev(val_accs) if len(val_accs) > 1 else 0,
            'test_acc_mean': statistics.mean(test_accs),
            'test_acc_std': statistics.stdev(test_accs) if len(test_accs) > 1 else 0,
        }
    }

    summary_path = os.path.join(output_dir, "repeat_experiment_summary.json")
    with open(summary_path, 'w', encoding='utf-8') as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)
    print(f"\n[Saved] Summary report: {summary_path}")

# ==================== entry point ====================
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Plant Disease Repeat Experiment")
    parser.add_argument("--seed", type=int, default=None, help="run a single seed")
    parser.add_argument("--no-resume", action="store_true", help="disable checkpoint resume")
    parser.add_argument("--output-dir", type=str, default=OUTPUT_DIR, help="Output directory")
    args = parser.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)

    if args.seed is not None:
        run_experiment(args.seed, args.output_dir, resume=not args.no_resume)
    else:
        for seed in SEEDS:
            run_experiment(seed, args.output_dir, resume=not args.no_resume)
        generate_summary(args.output_dir)
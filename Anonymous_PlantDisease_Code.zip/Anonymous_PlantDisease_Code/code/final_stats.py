import os
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""final_stats.py - final statistics for the main experiment (n=6, df=5, t=2.571)."""
import json, glob, os, statistics, math
ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

BASE = os.path.join(ROOT_DIR, "results", "main_experiment")
SEEDS = [42, 123, 456, 7, 77, 777]
T975 = 2.571
MODELS = ['resnet50', 'mobilenet_v2', 'efficientnet_b0']

rows = []
for p in glob.glob(f'{BASE}/*_history.json'):
    tag = os.path.basename(p).replace('_history.json', '')
    parts = tag.split('_')
    seed = int(parts[-1].replace('seed', ''))
    if seed not in SEEDS: continue
    d = json.load(open(p))
    rows.append(dict(model='_'.join(parts[:-3]), init=parts[-3].upper(),
                     aug=parts[-2], seed=seed, test=d['test_acc']))

def cell(m, i, a):
    return sorted(r['test'] for r in rows if r['model'] == m and r['init'] == i and r['aug'] == a)

print('=' * 72)
print(f'0. completeness: {len(rows)} files (expected 72)')
ok = True
for m in MODELS:
    for i in ['RI', 'PT']:
        for a in ['baseline', 'strong']:
            v = cell(m, i, a)
            if len(v) != 6:
                ok = False
                print(f'   [MISS] {m} {i} {a}: only {len(v)}  ')
print('   [OK] 72/72 complete' if ok else '   [WARN] incomplete')

def ms(v): return f'{statistics.mean(v):.2f} ± {statistics.stdev(v):.2f}'

print('\n1. Table 1 [n=6, mean+-SD %]')
t1 = {}
for m in MODELS:
    for i in ['RI', 'PT']:
        for a in ['baseline', 'strong']:
            v = cell(m, i, a); t1[(m, i, a)] = v
            print(f'{m:<18}{i:<5}{a:<10}{ms(v):>16}')

print('\n2. pretraining effect (PT-RI, paired diff)')
for m in MODELS:
    for a in ['baseline', 'strong']:
        ri, pt = t1[(m, 'RI', a)], t1[(m, 'PT', a)]
        if len(ri) == len(pt) == 6:
            diffs = [p - r for p, r in zip(pt, ri)]
            md, sd = statistics.mean(diffs), statistics.stdev(diffs)
            ci = T975 * sd / math.sqrt(6)
            sp = math.sqrt((statistics.variance(ri) + statistics.variance(pt)) / 2)
            print(f'   {m}+{a:<9}: Δ={md:+.2f}pp 95%CI=[{md-ci:+.2f},{md+ci:+.2f}] d={md/sp:+.2f}')

print('\n3. Table 2 interaction (delta = strong - baseline, pp)')
for m in MODELS:
    if all(len(t1[(m, i, a)]) == 6 for i in ['RI', 'PT'] for a in ['baseline', 'strong']):
        dR = statistics.mean(t1[(m,'RI','strong')]) - statistics.mean(t1[(m,'RI','baseline')])
        dP = statistics.mean(t1[(m,'PT','strong')]) - statistics.mean(t1[(m,'PT','baseline')])
        print(f'   {m:<18} RI:{dR:+.2f}  PT:{dP:+.2f}  interaction:{dP-dR:+.2f}')

print('\n4. Table 8 selection')
for k, lab in [(('efficientnet_b0','PT','baseline'),'EffB0+PT+baseline'),
               (('mobilenet_v2','PT','baseline'),'MobileNetV2+PT+baseline'),
               (('efficientnet_b0','PT','strong'),'EffB0+PT+strong')]:
    print(f'   {lab:26s}: {ms(t1[k])}')

json.dump(rows, open(os.path.join(ROOT_DIR, "results", "consolidated_final.json"), 'w'), indent=1)
print('\n[save] results/consolidated_final.json')
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Ablation experiment runner (with checkpoint resume)

Ablation design (6 groups, 21 cells): 
================================
Group A: data augmentation (fixed ResNet50 + ImageNet pretraining + seed=42)
  A1: no augmentation | A2: basic augmentation | A3: strong augmentation | A4: RandAugment

Group B: initialization (fixed ResNet50 + baseline augmentation + seed=42)
  B1: random initialization | B2: ImageNet pretraining | B3: pretraining + freezing the first 3 layers

Group C: model architecture (fixed baseline augmentation + ImageNet pretraining + seed=42)
  C1: ResNet18 | C2: ResNet50 | C3: MobileNetV2 | C4: EfficientNet-B0

Group D: learning rate (fixed ResNet50 + baseline + ImageNet pretraining + seed=42)
  D1: 1e-5 | D2: 5e-5 | D3: 1e-4 | D4: 5e-4

Group E: optimizer (fixed ResNet50 + baseline + ImageNet pretraining + seed=42)
  E1: AdamW | E2: SGD+Momentum | E3: RMSprop

Group F: batch size (fixed ResNet50 + baseline + ImageNet pretraining + seed=42)
  F1: 8 | F2: 12 | F3: 16 | F4: 32

Usage:
    python train_ablation.py              # run all ablation experiments
    python train_ablation.py --group A    # run group A only
    python train_ablation.py --exp A1     # run a single cell (A1)
    # rerun after interruption to resume automatically
"""

import os
import json
import time
import random
import argparse
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from torchvision import datasets, transforms, models
from torch.amp import autocast, GradScaler
from tqdm import tqdm

# ========== path configuration ==========
ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(ROOT_DIR, "data", "plantvillage_split")
SAVE_DIR = os.path.join(ROOT_DIR, "results", "ablation_experiment")
CHECKPOINT_DIR = os.path.join(ROOT_DIR, "checkpoints_ablation")
LOG_DIR = os.path.join(ROOT_DIR, "logs_ablation")
RESUME_PATH = os.path.join(CHECKPOINT_DIR, "ablation_resume_state.pt")

for d in [SAVE_DIR, CHECKPOINT_DIR, LOG_DIR]:
    os.makedirs(d, exist_ok=True)

DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f"Using device: {DEVICE}")
if DEVICE.type == 'cuda':
    print(f"GPU: {torch.cuda.get_device_name(0)}")
    print(f"GPU memory: {torch.cuda.get_device_properties(0).total_memory / 1024**3:.1f} GB")

# ========== global resume state ==========
resume_state = None


# ========== utility functions ==========
def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if DEVICE.type == 'cuda':
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


class RandAugment:
    """RandAugment implementation."""
    def __init__(self, n=2, m=9):
        self.n = n
        self.m = m
        self.augment_list = [
            transforms.AutoContrast(),
            transforms.Equalize(),
            transforms.ColorJitter(brightness=0.3),
            transforms.ColorJitter(contrast=0.3),
            transforms.ColorJitter(saturation=0.3),
            transforms.RandomRotation(degrees=15),
            transforms.RandomPosterize(bits=4),
            transforms.RandomSolarize(threshold=128),
        ]
    
    def __call__(self, img):
        ops = random.choices(self.augment_list, k=self.n)
        for op in ops:
            if random.random() < 0.5:
                img = op(img)
        return img


def get_transforms(aug_type='baseline'):
    """Return the data augmentation transforms."""
    if aug_type == 'none':
        train_transform = transforms.Compose([
            transforms.Resize((224, 224)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406],
                               std=[0.229, 0.224, 0.225])
        ])
    elif aug_type == 'baseline':
        train_transform = transforms.Compose([
            transforms.Resize((256, 256)),
            transforms.RandomCrop(224, padding=4),
            transforms.RandomHorizontalFlip(p=0.5),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406],
                               std=[0.229, 0.224, 0.225])
        ])
    elif aug_type == 'strong':
        train_transform = transforms.Compose([
            transforms.Resize((256, 256)),
            transforms.RandomCrop(224, padding=4),
            transforms.RandomHorizontalFlip(p=0.5),
            transforms.ColorJitter(brightness=0.2, contrast=0.2,
                                 saturation=0.2, hue=0.05),
            transforms.RandomRotation(degrees=15),
            transforms.GaussianBlur(kernel_size=3, sigma=(0.1, 2.0)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406],
                               std=[0.229, 0.224, 0.225])
        ])
    elif aug_type == 'randaug':
        train_transform = transforms.Compose([
            transforms.Resize((256, 256)),
            transforms.RandomCrop(224, padding=4),
            transforms.RandomHorizontalFlip(p=0.5),
            RandAugment(n=2, m=9),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406],
                               std=[0.229, 0.224, 0.225])
        ])
    else:
        raise ValueError(f"Unknown aug_type: {aug_type}")

    val_transform = transforms.Compose([
        transforms.Resize((256, 256)),
        transforms.CenterCrop(224),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406],
                           std=[0.229, 0.224, 0.225])
    ])
    return train_transform, val_transform


def get_data_loaders(data_dir, train_transform, val_transform, batch_size, num_workers=1):
    """loaddata"""
    train_dir = os.path.join(data_dir, 'train')
    val_dir = os.path.join(data_dir, 'val')
    test_dir = os.path.join(data_dir, 'test')

    train_dataset = datasets.ImageFolder(train_dir, transform=train_transform)
    val_dataset = datasets.ImageFolder(val_dir, transform=val_transform)
    test_dataset = datasets.ImageFolder(test_dir, transform=val_transform)

    train_loader = DataLoader(train_dataset, batch_size=batch_size,
                             shuffle=True, num_workers=num_workers,
                             pin_memory=True, drop_last=True)
    val_loader = DataLoader(val_dataset, batch_size=batch_size,
                           shuffle=False, num_workers=num_workers,
                           pin_memory=True)
    test_loader = DataLoader(test_dataset, batch_size=batch_size,
                            shuffle=False, num_workers=num_workers,
                            pin_memory=True)
    return train_loader, val_loader, test_loader, train_dataset.classes


def get_model(model_name, num_classes, pretrained=False, freeze_layers=0):
    """Build the model."""
    weights = 'IMAGENET1K_V1' if pretrained else None
    
    if model_name == 'resnet18':
        model = models.resnet18(weights=weights)
        model.fc = nn.Linear(model.fc.in_features, num_classes)
    elif model_name == 'resnet50':
        model = models.resnet50(weights=weights)
        model.fc = nn.Linear(model.fc.in_features, num_classes)
    elif model_name == 'mobilenet_v2':
        model = models.mobilenet_v2(weights=weights)
        model.classifier[1] = nn.Linear(model.classifier[1].in_features, num_classes)
    elif model_name == 'efficientnet_b0':
        model = models.efficientnet_b0(weights=weights)
        model.classifier[1] = nn.Linear(model.classifier[1].in_features, num_classes)
    else:
        raise ValueError(f"Unknown model: {model_name}")
    
    if freeze_layers > 0 and pretrained:
        children = list(model.children())
        for child in children[:freeze_layers]:
            for param in child.parameters():
                param.requires_grad = False
        print(f"  [freeze] first {freeze_layers} layer parameters")
    
    return model


def get_optimizer(optimizer_name, model_params, lr, weight_decay=1e-3):
    """Build the optimizer."""
    if optimizer_name == 'adamw':
        return optim.AdamW(model_params, lr=lr, weight_decay=weight_decay)
    elif optimizer_name == 'sgd':
        return optim.SGD(model_params, lr=lr, momentum=0.9, weight_decay=weight_decay)
    elif optimizer_name == 'rmsprop':
        return optim.RMSprop(model_params, lr=lr, weight_decay=weight_decay)
    else:
        raise ValueError(f"Unknown optimizer: {optimizer_name}")


def train_epoch(model, loader, criterion, optimizer, device, scaler=None):
    """Train for one epoch."""
    model.train()
    total_loss, correct, total = 0, 0, 0
    pbar = tqdm(loader, desc='Training')
    for inputs, labels in pbar:
        inputs, labels = inputs.to(device), labels.to(device)
        optimizer.zero_grad()
        if scaler is not None:
            with autocast(device_type="cuda"):
                outputs = model(inputs)
                loss = criterion(outputs, labels)
            scaler.scale(loss).backward()
            scaler.step(optimizer)
            scaler.update()
        else:
            outputs = model(inputs)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()
        total_loss += loss.item() * inputs.size(0)
        _, predicted = outputs.max(1)
        correct += predicted.eq(labels).sum().item()
        total += labels.size(0)
        pbar.set_postfix({
            'loss': f'{loss.item():.4f}',
            'acc': f'{100.*correct/total:.2f}%'
        })
    return total_loss / total, 100. * correct / total


@torch.no_grad()
def evaluate(model, loader, criterion, device):
    """Evaluate."""
    model.eval()
    total_loss, correct, total = 0, 0, 0
    for inputs, labels in tqdm(loader, desc='Evaluating'):
        inputs, labels = inputs.to(device), labels.to(device)
        outputs = model(inputs)
        loss = criterion(outputs, labels)
        total_loss += loss.item() * inputs.size(0)
        _, predicted = outputs.max(1)
        correct += predicted.eq(labels).sum().item()
        total += labels.size(0)
    return total_loss / total, 100. * correct / total


class WarmupScheduler:
    """Learning-rate scheduler with warm-up."""
    def __init__(self, optimizer, warmup_epochs, base_scheduler):
        self.optimizer = optimizer
        self.warmup_epochs = warmup_epochs
        self.base_scheduler = base_scheduler
        self.base_lr = optimizer.param_groups[0]['lr']
        self.current_epoch = 0

    def step(self, metric=None):
        self.current_epoch += 1
        if self.current_epoch <= self.warmup_epochs:
            warmup_factor = self.current_epoch / self.warmup_epochs
            for param_group in self.optimizer.param_groups:
                param_group['lr'] = self.base_lr * warmup_factor
        else:
            if self.base_scheduler is not None:
                if metric is not None:
                    self.base_scheduler.step(metric)
                else:
                    self.base_scheduler.step()

    def state_dict(self):
        return {
            'current_epoch': self.current_epoch,
            'base_scheduler': self.base_scheduler.state_dict() if self.base_scheduler else None
        }

    def load_state_dict(self, state_dict):
        self.current_epoch = state_dict['current_epoch']
        if self.base_scheduler and state_dict['base_scheduler']:
            self.base_scheduler.load_state_dict(state_dict['base_scheduler'])


# ========== checkpoint-resume core functions ==========
def save_resume_state(exp_cfg, epoch, model, optimizer, scheduler, scaler,
                      best_acc, history, epochs_no_improve, elapsed_time):
    """Save the global checkpoint state."""
    state = {
        'exp_cfg': exp_cfg,
        'epoch': epoch,
        'best_acc': best_acc,
        'epochs_no_improve': epochs_no_improve,
        'model_state_dict': model.state_dict(),
        'optimizer_state_dict': optimizer.state_dict(),
        'scheduler_state_dict': scheduler.state_dict(),
        'scaler_state_dict': scaler.state_dict() if scaler else None,
        'history': history,
        'elapsed_time': elapsed_time,
        'timestamp': time.time()
    }
    torch.save(state, RESUME_PATH)
    print(f"  [Checkpoint saved] epoch={epoch+1}, best_val_acc={best_acc:.2f}%")


def load_resume_state():
    """Load the global checkpoint state."""
    global resume_state
    if os.path.exists(RESUME_PATH):
        resume_state = torch.load(RESUME_PATH, map_location=DEVICE)
        cfg = resume_state['exp_cfg']
        print(f"\n{'='*70}")
        print(f"[checkpoint-resume] unfinished ablation experiment detected:")
        print(f"  experiment: {cfg['exp_id']}, group: {cfg['group']}")
        print(f"  model: {cfg['model']}, augmentation: {cfg['aug_type']}")
        print(f"  interrupted at epoch: {resume_state['epoch']+1}")
        print(f"  previous best: {resume_state['best_acc']:.2f}%")
        print(f"{'='*70}")
        return True
    return False


def clear_resume_state():
    """Clear the checkpoint."""
    global resume_state
    if os.path.exists(RESUME_PATH):
        os.remove(RESUME_PATH)
        print("  [checkpoint cleared]")
    resume_state = None


# ========== main training function ==========
def run_experiment(exp_cfg, epochs=80, patience=7, warmup_epochs=10):
    """Run a single ablation experiment."""
    global resume_state

    exp_id = exp_cfg['exp_id']
    model_name = exp_cfg['model']
    aug_type = exp_cfg['aug_type']
    pretrained = exp_cfg['pretrained']
    freeze_layers = exp_cfg.get('freeze_layers', 0)
    lr = exp_cfg['lr']
    batch_size = exp_cfg['batch_size']
    optimizer_name = exp_cfg['optimizer']
    seed = exp_cfg['seed']

    exp_tag = f"{exp_id}_{model_name}_{'pt' if pretrained else 'ri'}_{aug_type}_lr{lr}_bs{batch_size}_{optimizer_name}_seed{seed}"
    model_path = os.path.join(CHECKPOINT_DIR, f"{exp_tag}_best.pth")
    result_path = os.path.join(SAVE_DIR, f"{exp_tag}_history.json")

    # check whether already done
    if os.path.exists(result_path):
        print(f"\n[Skip] experiment already done: {exp_tag}")
        with open(result_path, 'r') as f:
            return json.load(f)

    # check checkpoint resume
    is_resuming = False
    start_epoch = 0
    elapsed_time = 0
    if resume_state is not None:
        saved_cfg = resume_state['exp_cfg']
        if saved_cfg['exp_id'] == exp_id:
            is_resuming = True
            start_epoch = resume_state['epoch'] + 1
            elapsed_time = resume_state.get('elapsed_time', 0)
            print(f"\n[resume] continuing from epoch {start_epoch}")

    # set the random seed
    set_seed(seed)

    print(f"\n{'='*70}")
    print(f"Ablation {exp_id}: {exp_cfg.get('description', '')}")
    init_type = "ImageNet pretraining" if pretrained else "random initialization"
    print(f"model: {model_name} | init: {init_type} | augmentation: {aug_type}")
    print(f"lr={lr}, batch={batch_size}, optimizer={optimizer_name}, seed={seed}")
    if is_resuming:
        print(f"[resume] continuing from epoch {start_epoch}")
    print(f"{'='*70}")

    # data loading
    train_transform, val_transform = get_transforms(aug_type)
    train_loader, val_loader, test_loader, classes = get_data_loaders(
        DATA_DIR, train_transform, val_transform, batch_size, num_workers=1
    )
    num_classes = len(classes)
    print(f"num classes: {num_classes}, train samples: {len(train_loader.dataset)}")

    # model
    model = get_model(model_name, num_classes, pretrained=pretrained, freeze_layers=freeze_layers)
    model = model.to(DEVICE)

    total_params = sum(p.numel() for p in model.parameters())
    trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"total params: {total_params:,} ({total_params/1e6:.2f}M)")
    print(f"trainable params: {trainable_params:,} ({trainable_params/1e6:.2f}M)")

    # optimizer
    criterion = nn.CrossEntropyLoss()
    optimizer = get_optimizer(optimizer_name, model.parameters(), lr=lr, weight_decay=1e-3)
    base_scheduler = optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, mode='max', factor=0.5, patience=5
    )
    scheduler = WarmupScheduler(optimizer, warmup_epochs, base_scheduler)
    scaler = GradScaler("cuda") if DEVICE.type == 'cuda' else None

    # resume or initialize
    if is_resuming:
        model.load_state_dict(resume_state['model_state_dict'])
        optimizer.load_state_dict(resume_state['optimizer_state_dict'])
        scheduler.load_state_dict(resume_state['scheduler_state_dict'])
        if scaler and resume_state['scaler_state_dict']:
            scaler.load_state_dict(resume_state['scaler_state_dict'])
        history = resume_state['history']
        best_acc = resume_state['best_acc']
        epochs_no_improve = resume_state['epochs_no_improve']
        print(f"[resume state] best_acc={best_acc:.2f}%, epochs_no_improve={epochs_no_improve}")
    else:
        history = {
            'exp_id': exp_id, 'group': exp_cfg['group'],
            'model': model_name, 'aug_type': aug_type,
            'pretrained': pretrained, 'freeze_layers': freeze_layers,
            'lr': lr, 'batch_size': batch_size, 'optimizer': optimizer_name,
            'seed': seed, 'description': exp_cfg.get('description', ''),
            'train_loss': [], 'train_acc': [],
            'val_loss': [], 'val_acc': [],
            'epochs': [], 'learning_rates': []
        }
        best_acc = 0.0
        epochs_no_improve = 0

    start_time = time.time()

    # training loop
    for epoch in range(start_epoch, epochs):
        print(f"\nEpoch {epoch+1}/{epochs}")
        train_loss, train_acc = train_epoch(
            model, train_loader, criterion, optimizer, DEVICE, scaler
        )
        val_loss, val_acc = evaluate(model, val_loader, criterion, DEVICE)
        current_lr = optimizer.param_groups[0]['lr']

        history['epochs'].append(epoch + 1)
        history['train_loss'].append(train_loss)
        history['train_acc'].append(train_acc)
        history['val_loss'].append(val_loss)
        history['val_acc'].append(val_acc)
        history['learning_rates'].append(current_lr)

        print(f"Train Loss: {train_loss:.4f}, Train Acc: {train_acc:.2f}%")
        print(f"Val Loss: {val_loss:.4f}, Val Acc: {val_acc:.2f}%")
        print(f"LR: {current_lr:.6f}")

        scheduler.step(val_acc)

        # save the best model
        if val_acc > best_acc:
            best_acc = val_acc
            torch.save({
                'epoch': epoch,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'val_acc': val_acc,
                'classes': classes
            }, model_path)
            print(f"  -> savebestmodel (Val Acc: {best_acc:.2f}%)")
            epochs_no_improve = 0
        else:
            epochs_no_improve += 1

        # save checkpoint
        current_elapsed = elapsed_time + (time.time() - start_time)
        save_resume_state(exp_cfg, epoch, model, optimizer, scheduler, scaler,
                          best_acc, history, epochs_no_improve, current_elapsed)

        # early stopping
        if epochs_no_improve >= patience:
            print(f"\nearly stopping triggered: no val-accuracy improvement for {patience} epochs")
            break

    total_elapsed = elapsed_time + (time.time() - start_time)

    print(f"\ntraining done! total time: {total_elapsed/3600:.2f} h")
    print(f"bestvalaccuracy: {best_acc:.2f}%")

    # evaluate on the test set
    print(f"\nevaluating the best model on the test set ...")
    checkpoint = torch.load(model_path, map_location=DEVICE)
    model.load_state_dict(checkpoint['model_state_dict'])
    test_loss, test_acc = evaluate(model, test_loader, criterion, DEVICE)
    print(f"Test accuracy: {test_acc:.2f}%")

    # fill in the history record
    history['test_acc'] = test_acc
    history['best_val_acc'] = best_acc
    history['best_epoch'] = epoch + 1
    history['total_time'] = total_elapsed
    history['total_params'] = total_params
    history['trainable_params'] = trainable_params
    history['completed'] = True

    # save the results
    with open(result_path, 'w') as f:
        json.dump(history, f, indent=2)
    print(f"Results saved: {result_path}")

    # clear the checkpoint
    clear_resume_state()

    return history


# ========== experiment configuration ==========
def get_ablation_experiments():
    """Define all ablation experiments."""
    experiments = []

    # Group A: data augmentation (fixed ResNet50 + PT + seed=42)
    aug_types = [
        ('A1', 'none', 'no augmentation'),
        ('A2', 'baseline', 'basic augmentation'),
        ('A3', 'strong', 'strong augmentation'),
        ('A4', 'randaug', 'RandAugment'),
    ]
    for exp_id, aug, desc in aug_types:
        experiments.append({
            'exp_id': exp_id, 'group': 'A',
            'model': 'resnet50', 'aug_type': aug,
            'pretrained': True, 'freeze_layers': 0,
            'lr': 5e-5, 'batch_size': 16, 'optimizer': 'adamw',
            'seed': 42, 'description': desc
        })

    # Group B: initialization (fixed ResNet50 + baseline + seed=42)
    init_configs = [
        ('B1', False, 0, 'random initialization', 1e-3),
        ('B2', True, 0, 'ImageNet pretraining', 5e-5),
        ('B3', True, 3, 'pretraining + freezing the first 3 layers', 5e-5),
        ('B1s', False, 0, 'random init (controlled lr)', 5e-5),
    ]
    for exp_id, pt, freeze, desc, lr in init_configs:
        experiments.append({
            'exp_id': exp_id, 'group': 'B',
            'model': 'resnet50', 'aug_type': 'baseline',
            'pretrained': pt, 'freeze_layers': freeze,
            'lr': lr, 'batch_size': 16, 'optimizer': 'adamw',
            'seed': 42, 'description': desc
        })

    # Group C: model architecture (fixed baseline + PT + seed=42)
    for i, model in enumerate(['resnet18', 'resnet50', 'mobilenet_v2', 'efficientnet_b0']):
        experiments.append({
            'exp_id': f"C{i+1}", 'group': 'C',
            'model': model, 'aug_type': 'baseline',
            'pretrained': True, 'freeze_layers': 0,
            'lr': 5e-5, 'batch_size': 16, 'optimizer': 'adamw',
            'seed': 42, 'description': model
        })

    # Group D: learning rate (fixed ResNet50 + baseline + PT + seed=42)
    for i, lr in enumerate([1e-5, 5e-5, 1e-4, 5e-4]):
        experiments.append({
            'exp_id': f"D{i+1}", 'group': 'D',
            'model': 'resnet50', 'aug_type': 'baseline',
            'pretrained': True, 'freeze_layers': 0,
            'lr': lr, 'batch_size': 16, 'optimizer': 'adamw',
            'seed': 42, 'description': f'lr={lr}'
        })

    # Group E: optimizer (fixed ResNet50 + baseline + PT + seed=42)
    for i, opt in enumerate(['adamw', 'sgd', 'rmsprop']):
        experiments.append({
            'exp_id': f"E{i+1}", 'group': 'E',
            'model': 'resnet50', 'aug_type': 'baseline',
            'pretrained': True, 'freeze_layers': 0,
            'lr': 5e-5, 'batch_size': 16, 'optimizer': opt,
            'seed': 42, 'description': opt.upper()
        })

    # Group F: batch size (fixed ResNet50 + baseline + PT + seed=42)
    for i, bs in enumerate([8, 12, 16, 32]):
        experiments.append({
            'exp_id': f"F{i+1}", 'group': 'F',
            'model': 'resnet50', 'aug_type': 'baseline',
            'pretrained': True, 'freeze_layers': 0,
            'lr': 5e-5, 'batch_size': bs, 'optimizer': 'adamw',
            'seed': 42, 'description': f'batch={bs}'
        })

    return experiments


# ========== main ==========
if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Ablation experiments on PlantVillage')
    parser.add_argument('--group', type=str, default=None,
                        help='run a specified group (A/B/C/D/E/F); all groups if omitted')
    parser.add_argument('--exp', type=str, default=None,
                        help='run a specified experiment (e.g., A1, B2)')
    parser.add_argument('--seed', type=int, default=None,
                        help='override the seed for all experiments')
    args = parser.parse_args()

    all_experiments = get_ablation_experiments()

    # filter experiments
    if args.exp:
        experiments = [e for e in all_experiments if e['exp_id'] == args.exp]
        if not experiments:
            print(f"Error: experiment not found: {args.exp}")
            exit(1)
    elif args.group:
        experiments = [e for e in all_experiments if e['group'] == args.group.upper()]
        if not experiments:
            print(f"Error: group not found: {args.group}")
            exit(1)
    else:
        experiments = all_experiments

    if args.seed:
        for _e in experiments:
            _e['seed'] = args.seed

    print(f"\nplanned: {len(experiments)} ablation experiments")
    for e in experiments:
        print(f"  {e['exp_id']}: {e['description']}")

    has_resume = False  # checkpoint resume is isolated per experiment and seed inside the loop

    all_results = []
    skipped = 0

    for exp_cfg in experiments:
        exp_id = exp_cfg['exp_id']

        # check whether results already exist
        exp_tag = f"{exp_id}_{exp_cfg['model']}_{'pt' if exp_cfg['pretrained'] else 'ri'}_{exp_cfg['aug_type']}_lr{exp_cfg['lr']}_bs{exp_cfg['batch_size']}_{exp_cfg['optimizer']}_seed{exp_cfg['seed']}"
        result_path = os.path.join(SAVE_DIR, f"{exp_tag}_history.json")

        if os.path.exists(result_path):
            print(f"[Skip] already exists: {exp_tag}")
            with open(result_path, 'r') as f:
                all_results.append(json.load(f))
            skipped += 1
            continue

        # per-experiment checkpoint: resume only this experiment and seed
        import sys as _sm, os as _os
        _sm.modules['__main__'].__dict__['RESUME_PATH'] = _os.path.join(
            CHECKPOINT_DIR, f"abl_resume_{exp_tag}.pt")
        has_resume = load_resume_state()
        if has_resume and resume_state is not None:
            _sc = resume_state['exp_cfg']
            if _sc['exp_id'] != exp_id or _sc.get('seed') != exp_cfg['seed']:
                print(f"[ignore] checkpoint mismatch; starting from scratch: {exp_tag}")
                globals()['resume_state'] = None
                has_resume = False

        try:
            if DEVICE.type == 'cuda':
                torch.cuda.empty_cache()

            history = run_experiment(exp_cfg, epochs=80, patience=7, warmup_epochs=10)
            all_results.append(history)

        except Exception as e:
            print(f"\n[Error] Experiment failed: {exp_id}")
            print(f"Error: {str(e)}")
            import traceback
            traceback.print_exc()
            continue

    # save summary
    summary_path = os.path.join(SAVE_DIR, 'ablation_summary.json')
    with open(summary_path, 'w') as f:
        json.dump(all_results, f, indent=2)

    print(f"\n{'='*70}")
    print("Ablation batch finished!")
    print(f"{'='*70}")
    print(f"total: {len(all_results)} experiments (skipped {skipped} already done)")

    # print results by group
    groups = sorted(set(r['group'] for r in all_results))
    for group in groups:
        group_results = [r for r in all_results if r['group'] == group]
        print(f"\n{'='*70}")
        print(f"group {group} results")
        print(f"{'='*70}")
        print(f"{'experiment':<8} {'description':<25} {'testAcc':<10} {'time(h)':<10}")
        print("-" * 60)
        for r in group_results:
            print(f"{r['exp_id']:<8} {r['description']:<25} {r['test_acc']:<10.2f} {r['total_time']/3600:<10.2f}")

    # checkpoint warning
    if os.path.exists(RESUME_PATH):
        print(f"\n{'!'*70}")
        print("[Warning] unresumed checkpoint remains; rerun the script to continue")
        print(f"checkpointfile: {RESUME_PATH}")
        print(f"{'!'*70}")

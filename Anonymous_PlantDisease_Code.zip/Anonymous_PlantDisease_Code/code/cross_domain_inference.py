"""
cross_domain_inference.py
Supplementary cross-domain inference script (no scikit-learn dependency)
Re-runs inference on the PlantDoc test set with saved model weights and produces detailed per-class results
"""

import os
import sys
import json
import argparse
import warnings
from collections import Counter, defaultdict
from PIL import Image

import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from torchvision import models, transforms
from torchvision.datasets import ImageFolder
import numpy as np

warnings.filterwarnings("ignore")

# ========== path configuration (same as the training code) ==========
ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(ROOT_DIR, "data", "plantvillage_split")
PLANTDOC_DIR = os.path.join(ROOT_DIR, "data", "plantdoc_raw")
CHECKPOINT_DIR = os.path.join(ROOT_DIR, "checkpoints_cross")
OUTPUT_DIR = os.path.join(ROOT_DIR, "results", "cross_domain_detailed")

os.makedirs(OUTPUT_DIR, exist_ok=True)

DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f"Using device: {DEVICE}")

# ========== PlantDoc -> PlantVillage class mapping ==========
PLANTDOC_TO_PLANTVILLAGE_MAP = {
    'Apple leaf': 'Apple___healthy',
    'Apple rust leaf': 'Apple___Cedar_apple_rust',
    'Apple Scab Leaf': 'Apple___Apple_scab',
    'Bell_pepper leaf': 'Pepper,_bell___healthy',
    'Bell_pepper leaf spot': 'Pepper,_bell___Bacterial_spot',
    'Blueberry leaf': 'Blueberry___healthy',
    'Cherry leaf': 'Cherry_(including_sour)___healthy',
    'Corn Gray leaf spot': 'Corn_(maize)___Cercospora_leaf_spot Gray_leaf_spot',
    'Corn leaf blight': 'Corn_(maize)___Northern_Leaf_Blight',
    'Corn rust leaf': 'Corn_(maize)___Common_rust',
    'grape leaf': 'Grape___healthy',
    'grape leaf black rot': 'Grape___Black_rot',
    'Peach leaf': 'Peach___healthy',
    'Potato leaf early blight': 'Potato___Early_blight',
    'Potato leaf late blight': 'Potato___Late_blight',
    'Raspberry leaf': 'Raspberry___healthy',
    'Soyabean leaf': 'Soybean___healthy',
    'Squash Powdery mildew leaf': 'Squash___Powdery_mildew',
    'Strawberry leaf': 'Strawberry___healthy',
    'Tomato Early blight leaf': 'Tomato___Early_blight',
    'Tomato leaf': 'Tomato___healthy',
    'Tomato leaf bacterial spot': 'Tomato___Bacterial_spot',
    'Tomato leaf late blight': 'Tomato___Late_blight',
    'Tomato leaf mosaic virus': 'Tomato___Tomato_mosaic_virus',
    'Tomato leaf yellow virus': 'Tomato___Tomato_Yellow_Leaf_Curl_Virus',
    'Tomato mold leaf': 'Tomato___Leaf_Mold',
    'Tomato Septoria leaf spot': 'Tomato___Septoria_leaf_spot',
}

# ========== PlantDoc dataset ==========
class PlantDocDataset(torch.utils.data.Dataset):
    def __init__(self, root_dir, plantvillage_classes, transform=None, split='test'):
        self.root_dir = root_dir
        self.transform = transform
        self.split = split
        self.pv_class_to_idx = {cls: idx for idx, cls in enumerate(plantvillage_classes)}
        self.samples = self._load_and_map_samples()
        self.mapped_classes = sorted(set(label for _, label in self.samples))
        print(f"PlantDoc {split}: {len(self.samples)} valid images, {len(self.mapped_classes)} mapped classes")

    def _load_and_map_samples(self):
        samples = []
        if self.split == 'all':
            split_dirs = []
            for s in ['train', 'test']:
                d = os.path.join(self.root_dir, s)
                if os.path.isdir(d):
                    split_dirs.append(d)
        else:
            split_dir = os.path.join(self.root_dir, self.split)
            if not os.path.exists(split_dir):
                split_dir = self.root_dir
            split_dirs = [split_dir]

        for split_dir in split_dirs:
            if not os.path.isdir(split_dir):
                continue
            for doc_class in sorted(os.listdir(split_dir)):
                doc_class_path = os.path.join(split_dir, doc_class)
                if not os.path.isdir(doc_class_path):
                    continue
                pv_class = PLANTDOC_TO_PLANTVILLAGE_MAP.get(doc_class)
                if pv_class is None or pv_class not in self.pv_class_to_idx:
                    continue
                pv_idx = self.pv_class_to_idx[pv_class]
                for img_name in os.listdir(doc_class_path):
                    if not img_name.lower().endswith(('.jpg', '.jpeg', '.png', '.bmp')):
                        continue
                    img_path = os.path.join(doc_class_path, img_name)
                    try:
                        with Image.open(img_path) as img:
                            img.verify()
                        with Image.open(img_path) as img:
                            img.convert('RGB')
                        samples.append((img_path, pv_idx))
                    except:
                        pass
        return samples

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        img_path, label = self.samples[idx]
        try:
            image = Image.open(img_path).convert('RGB')
        except:
            image = Image.new('RGB', (224, 224), (128, 128, 128))
        if self.transform:
            image = self.transform(image)
        return image, label


# ========== DANN components ==========
class GradientReversalLayer(torch.autograd.Function):
    @staticmethod
    def forward(ctx, x, alpha):
        ctx.alpha = alpha
        return x.view_as(x)
    @staticmethod
    def backward(ctx, grad_output):
        return grad_output.neg() * ctx.alpha, None

class DomainDiscriminator(nn.Module):
    def __init__(self, input_dim=1280, hidden_dim=256):
        super().__init__()
        self.network = nn.Sequential(
            nn.Linear(input_dim, hidden_dim), nn.ReLU(), nn.Dropout(0.5),
            nn.Linear(hidden_dim, 1)
        )
    def forward(self, x):
        return self.network(x)

class DANNModel(nn.Module):
    def __init__(self, base_model, num_classes=38):
        super().__init__()
        self.alpha = 0.0
        if hasattr(base_model, 'classifier'):
            self.feature_dim = base_model.classifier[1].in_features
            base_model.classifier = nn.Identity()
        else:
            self.feature_dim = 1280
        self.feature_extractor = base_model
        self.classifier = nn.Linear(self.feature_dim, num_classes)
        self.domain_discriminator = DomainDiscriminator(self.feature_dim)
    def forward(self, x, mode='feature'):
        features = self.feature_extractor(x)
        if mode == 'feature':
            return features
        elif mode == 'class':
            return self.classifier(features)
        elif mode == 'domain':
            reversed_features = GradientReversalLayer.apply(features, self.alpha)
            return self.domain_discriminator(reversed_features).squeeze()
        else:
            raise ValueError(f"Unknown mode: {mode}")


# ========== data transforms ==========
def get_val_transform():
    return transforms.Compose([
        transforms.Resize((256, 256)),
        transforms.CenterCrop(224),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
    ])


# ========== pure-NumPy confusion matrix ==========
def compute_confusion_matrix(y_true, y_pred, num_classes):
    """Confusion matrix implemented with pure NumPy; no scikit-learn required."""
    cm = np.zeros((num_classes, num_classes), dtype=np.int64)
    for t, p in zip(y_true, y_pred):
        cm[t, p] += 1
    return cm


# ========== inference function ==========
@torch.no_grad()
def inference_collect(model, dataloader, device, is_dann=False):
    model.eval()
    all_preds = []
    all_labels = []

    for batch_idx, (inputs, labels) in enumerate(dataloader):
        inputs = inputs.to(device)
        if is_dann:
            features = model(inputs, mode='feature')
            outputs = model.classifier(features)
        else:
            outputs = model(inputs)
        _, predicted = outputs.max(1)
        all_preds.extend(predicted.cpu().numpy().tolist())
        all_labels.extend(labels.numpy().tolist())
        if (batch_idx + 1) % 10 == 0 or batch_idx == 0:
            print(f"  [Inference] Batch {batch_idx+1}/{len(dataloader)} done")

    return np.array(all_preds), np.array(all_labels)


# ========== per-class statistics ==========
def compute_class_metrics(y_true, y_pred, class_names):
    num_classes = len(class_names)
    cm = compute_confusion_matrix(y_true, y_pred, num_classes)

    class_metrics = {}
    for i, name in enumerate(class_names):
        tp = cm[i, i]
        fp = cm[:, i].sum() - tp
        fn = cm[i, :].sum() - tp
        support = cm[i, :].sum()

        precision = tp / (tp + fp) if (tp + fp) > 0 else 0
        recall = tp / (tp + fn) if (tp + fn) > 0 else 0
        f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0

        confused = {}
        for j in range(num_classes):
            if i != j and cm[i, j] > 0:
                confused[class_names[j]] = int(cm[i, j])

        class_metrics[name] = {
            "precision": round(precision * 100, 2),
            "recall": round(recall * 100, 2),
            "f1_score": round(f1 * 100, 2),
            "support": int(support),
            "correct": int(tp),
            "confused_with": dict(sorted(confused.items(), key=lambda x: -x[1])[:3])
        }

    return cm, class_metrics


# ========== main inference pipeline ==========
def run_inference(exp_type, seed, model_path, output_dir):
    print(f"\n{'='*70}")
    print(f"inference: {exp_type} | seed={seed}")
    print(f"model: {model_path}")
    print(f"{'='*70}")

    if not os.path.exists(model_path):
        print(f"[ERROR] model file not found: {model_path}")
        return None

    # load the PlantVillage class list
    pv_train_dir = os.path.join(DATA_DIR, 'train')
    if not os.path.exists(pv_train_dir):
        print(f"[ERROR] PlantVillage train directory not found: {pv_train_dir}")
        return None

    temp_dataset = ImageFolder(pv_train_dir)
    pv_classes = temp_dataset.classes
    print(f"PlantVillage classes: {len(pv_classes)}")

    # Loading model
    print("[Info] Loading model...")
    if exp_type == 'dann':
        base_model = models.efficientnet_b0(weights=None)
        model = DANNModel(base_model, num_classes=38).to(DEVICE)
        checkpoint = torch.load(model_path, map_location=DEVICE)
        if isinstance(checkpoint, dict) and 'model_state' in checkpoint:
            model.load_state_dict(checkpoint['model_state'])
        else:
            state = checkpoint.get('model_state_dict', checkpoint) if isinstance(checkpoint, dict) else checkpoint
            model.load_state_dict(state)
        is_dann = True
    else:
        model = models.efficientnet_b0(weights=None)
        model.classifier[1] = nn.Linear(model.classifier[1].in_features, 38)
        model = model.to(DEVICE)
        checkpoint = torch.load(model_path, map_location=DEVICE)
        if isinstance(checkpoint, dict) and 'model_state' in checkpoint:
            model.load_state_dict(checkpoint['model_state'])
        else:
            model.load_state_dict(checkpoint)
        is_dann = False

    print("[Info] Model loaded")

    # Loading PlantDoc test set
    print("[Info] Loading PlantDoc test set...")
    val_transform = get_val_transform()
    plantdoc_test = PlantDocDataset(PLANTDOC_DIR, pv_classes, transform=val_transform, split='test')

    if len(plantdoc_test) == 0:
        print("[ERROR] PlantDoc test set is empty; trying all data ...")
        plantdoc_test = PlantDocDataset(PLANTDOC_DIR, pv_classes, transform=val_transform, split='all')

    if len(plantdoc_test) == 0:
        print("[ERROR] PlantDoc data failed to load")
        return None

    test_loader = DataLoader(plantdoc_test, batch_size=32, shuffle=False, num_workers=0, pin_memory=False)
    print(f"[Info] PlantDoc test set: {len(plantdoc_test)}  images")

    # inference
    print("[Info] Starting inference...")
    y_pred, y_true = inference_collect(model, test_loader, DEVICE, is_dann=is_dann)

    # Overall accuracy
    overall_acc = (y_pred == y_true).mean() * 100
    print(f"[Result] Overall accuracy: {overall_acc:.2f}%")

    # per-class statistics
    print("[Info] computing per-class metrics...")
    cm, class_metrics = compute_class_metrics(y_true, y_pred, pv_classes)

    # create the output directory
    exp_output_dir = os.path.join(output_dir, f"{exp_type}_seed{seed}")
    os.makedirs(exp_output_dir, exist_ok=True)

    # 1. save per-sample predictions
    sample_results = []
    for idx in range(len(y_true)):
        sample_results.append({
            "index": idx,
            "true_label": int(y_true[idx]),
            "true_class": pv_classes[y_true[idx]],
            "pred_label": int(y_pred[idx]),
            "pred_class": pv_classes[y_pred[idx]],
            "correct": bool(y_true[idx] == y_pred[idx])
        })

    with open(os.path.join(exp_output_dir, "sample_predictions.json"), 'w', encoding='utf-8') as f:
        json.dump(sample_results, f, indent=2, ensure_ascii=False)

    # 2. save the confusion matrix
    with open(os.path.join(exp_output_dir, "confusion_matrix.json"), 'w', encoding='utf-8') as f:
        json.dump({"matrix": cm.tolist(), "class_names": pv_classes}, f, indent=2, ensure_ascii=False)

    # 3. save per-class metrics
    with open(os.path.join(exp_output_dir, "class_metrics.json"), 'w', encoding='utf-8') as f:
        json.dump(class_metrics, f, indent=2, ensure_ascii=False)

    # 4. save CSV
    import csv
    csv_path = os.path.join(exp_output_dir, "class_metrics.csv")
    with open(csv_path, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(["class", "precision(%)", "recall(%)", "F1(%)", "samples", "correct"])
        for name, metrics in class_metrics.items():
            writer.writerow([
                name, metrics['precision'], metrics['recall'],
                metrics['f1_score'], metrics['support'], metrics['correct']
            ])

    # 5. save summary
    summary = {
        "exp_type": exp_type,
        "seed": seed,
        "model_path": model_path,
        "overall_accuracy": round(overall_acc, 2),
        "num_samples": len(y_true),
        "num_classes": len(pv_classes),
        "class_metrics": class_metrics,
        "top5_best": sorted(class_metrics.items(), key=lambda x: -x[1]['recall'])[:5],
        "top5_worst": sorted(class_metrics.items(), key=lambda x: x[1]['recall'])[:5]
    }

    with open(os.path.join(exp_output_dir, "summary.json"), 'w', encoding='utf-8') as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)

    print(f"[Saved] Results saved to: {exp_output_dir}")
    print(f"  - sample_predictions.json")
    print(f"  - confusion_matrix.json")
    print(f"  - class_metrics.json")
    print(f"  - class_metrics.csv (readable in Excel)")
    print(f"  - summary.json")

    return summary


# ========== batch inference over all experiments ==========
def run_all():
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    experiments = [
        ("source_only", 42, os.path.join(CHECKPOINT_DIR, "source_only_seed42_best.pth")),
        ("source_only", 123, os.path.join(CHECKPOINT_DIR, "source_only_seed123_best.pth")),
        ("source_only", 456, os.path.join(CHECKPOINT_DIR, "source_only_seed456_best.pth")),
        ("dann", 42, os.path.join(CHECKPOINT_DIR, "dann_seed42_best.pth")),
        ("dann", 123, os.path.join(CHECKPOINT_DIR, "dann_seed123_best.pth")),
        ("dann", 456, os.path.join(CHECKPOINT_DIR, "dann_seed456_best.pth")),
    ]

    all_summaries = []

    for exp_type, seed, model_path in experiments:
        if not os.path.exists(model_path):
            print(f"\n[WARN] model not found: {model_path}")
            alt_path = model_path.replace("_best.pth", "_checkpoint.pth")
            if os.path.exists(alt_path):
                print(f"  trying: {alt_path}")
                model_path = alt_path
            else:
                continue

        summary = run_inference(exp_type, seed, model_path, OUTPUT_DIR)
        if summary:
            all_summaries.append(summary)

    if all_summaries:
        with open(os.path.join(OUTPUT_DIR, "all_experiments_summary.json"), 'w', encoding='utf-8') as f:
            json.dump(all_summaries, f, indent=2, ensure_ascii=False)
        print(f"\n[Saved] overall summary: {os.path.join(OUTPUT_DIR, 'all_experiments_summary.json')}")


# ========== entry point ==========
if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--exp-type', type=str, default=None, help='source_only or dann')
    parser.add_argument('--seed', type=int, default=None, help='seed value')
    parser.add_argument('--model-path', type=str, default=None, help='path to the model checkpoint')
    args = parser.parse_args()

    if args.exp_type and args.seed and args.model_path:
        run_inference(args.exp_type, args.seed, args.model_path, OUTPUT_DIR)
    else:
        run_all()
import os
import sys
import json
import time
import random
import argparse
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, Dataset
from torchvision import datasets, transforms, models
from tqdm import tqdm
from PIL import Image
from collections import Counter

# ========== path configuration ==========
ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(ROOT_DIR, "data", "plantvillage_split")
PLANTDOC_DIR = os.path.join(ROOT_DIR, "data", "plantdoc_raw")  # note: removed the trailing /PlantDoc-Dataset

SAVE_DIR = os.path.join(ROOT_DIR, "results", "cross_domain")
CHECKPOINT_DIR = os.path.join(ROOT_DIR, "checkpoints_cross")

for d in [SAVE_DIR, CHECKPOINT_DIR]:
    os.makedirs(d, exist_ok=True)

DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f"Using device: {DEVICE}")
if DEVICE.type == 'cuda':
    print(f"GPU: {torch.cuda.get_device_name(0)}")
    print(f"GPU memory: {torch.cuda.get_device_properties(0).total_memory / 1024**3:.1f} GB")

# paths
print(f"\nPlantVillage path: {DATA_DIR}")
print(f"  exists: {os.path.exists(DATA_DIR)}")
print(f"PlantDoc path: {PLANTDOC_DIR}")
print(f"  exists: {os.path.exists(PLANTDOC_DIR)}")

if not os.path.exists(DATA_DIR):
    print("Error: PlantVillagePath not found!")
    sys.exit(1)
if not os.path.exists(PLANTDOC_DIR):
    print("Error: PlantDocPath not found!")
    sys.exit(1)

# ========== PlantDoc -> PlantVillage class mapping (based on folder names) ==========
PLANTDOC_TO_PLANTVILLAGE_MAP = {
    # Apple
    'Apple leaf': 'Apple___healthy',
    'Apple rust leaf': 'Apple___Cedar_apple_rust',
    'Apple Scab Leaf': 'Apple___Apple_scab',

    # Bell pepper
    'Bell_pepper leaf': 'Pepper,_bell___healthy',
    'Bell_pepper leaf spot': 'Pepper,_bell___Bacterial_spot',

    # Blueberry
    'Blueberry leaf': 'Blueberry___healthy',

    # Cherry (disease type cannot be distinguished; mapped to healthy)
    'Cherry leaf': 'Cherry___healthy',

    # Corn (maize)
    'Corn Gray leaf spot': 'Corn___Cercospora_leaf_spot Gray_leaf_spot',
    'Corn leaf blight': 'Corn___Northern_Leaf_Blight',
    'Corn rust leaf': 'Corn___Common_rust',

    # Grape
    'grape leaf': 'Grape___healthy',
    'grape leaf black rot': 'Grape___Black_rot',

    # Peach (disease type cannot be distinguished)
    'Peach leaf': 'Peach___healthy',

    # Potato
    'Potato leaf early blight': 'Potato___Early_blight',
    'Potato leaf late blight': 'Potato___Late_blight',

    # Raspberry
    'Raspberry leaf': 'Raspberry___healthy',

    # Soybean (note the spelling difference: Soyabean vs Soybean)
    'Soyabean leaf': 'Soybean___healthy',

    # Squash
    'Squash Powdery mildew leaf': 'Squash___Powdery_mildew',

    # Strawberry (disease type cannot be distinguished)
    'Strawberry leaf': 'Strawberry___healthy',

    # Tomato
    'Tomato Early blight leaf': 'Tomato___Early_blight',
    'Tomato leaf': 'Tomato___healthy',
    'Tomato leaf bacterial spot': 'Tomato___Bacterial_spot',
    'Tomato leaf late blight': 'Tomato___Late_blight',
    'Tomato leaf mosaic virus': 'Tomato___Tomato_mosaic_virus',
    'Tomato leaf yellow virus': 'Tomato___Tomato_Yellow_Leaf_Curl_Virus',
    'Tomato mold leaf': 'Tomato___Leaf_Mold',
    'Tomato Septoria leaf spot': 'Tomato___Septoria_leaf_spot',
}


# ========== utility functions ==========
def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if DEVICE.type == 'cuda':
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def get_transforms(aug_type='strong'):
    """Return the data augmentation transforms."""
    if aug_type == 'baseline':
        train_transform = transforms.Compose([
            transforms.Resize((256, 256)),
            transforms.RandomCrop(224, padding=4),
            transforms.RandomHorizontalFlip(p=0.5),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406],
                               std=[0.229, 0.224, 0.225])
        ])
    elif aug_type == 'strong':
        train_transform = transforms.Compose([
            transforms.Resize((256, 256)),
            transforms.RandomCrop(224, padding=4),
            transforms.RandomHorizontalFlip(p=0.5),
            transforms.ColorJitter(brightness=0.2, contrast=0.2,
                                 saturation=0.2, hue=0.05),
            transforms.RandomRotation(degrees=15),
            transforms.GaussianBlur(kernel_size=3, sigma=(0.1, 2.0)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406],
                               std=[0.229, 0.224, 0.225])
        ])
    else:
        raise ValueError(f"Unknown aug_type: {aug_type}")

    val_transform = transforms.Compose([
        transforms.Resize((256, 256)),
        transforms.CenterCrop(224),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406],
                           std=[0.229, 0.224, 0.225])
    ])
    return train_transform, val_transform


# ========== PlantDoc dataset (with class mapping) ==========
class PlantDocDataset(Dataset):
    """
    PlantDoc dataset, automatically mapped to the 38 PlantVillage classes
    Skips unmappable classes and corrupted images
    """

    def __init__(self, root_dir, plantvillage_classes, transform=None, split='test'):
        self.root_dir = root_dir
        self.transform = transform
        self.split = split

        # build the class-index mapping
        self.pv_class_to_idx = {cls: idx for idx, cls in enumerate(plantvillage_classes)}

        # load and map samples
        self.samples = self._load_and_map_samples()

        # statistics
        self.mapped_classes = sorted(set(label for _, label in self.samples))
        print(f"PlantDoc {split}: {len(self.samples)} valid images")
        print(f"  mappable classes: {len(self.mapped_classes)}/38")
        if self.samples:
            print(f"  class distribution: {Counter(self.pv_class_to_idx_inv(label) for _, label in self.samples).most_common(5)}")

    def _load_and_map_samples(self):
        """Load samples and map their classes."""
        samples = []

        # explicitly handle split='all' by merging train + test
        if self.split == 'all':
            split_dirs = []
            for s in ['train', 'test']:
                d = os.path.join(self.root_dir, s)
                if os.path.isdir(d):
                    split_dirs.append(d)
            if not split_dirs:
                print(f"Warning: no train/test directory found under {self.root_dir}")
                return []
        else:
            split_dir = os.path.join(self.root_dir, self.split)
            if not os.path.exists(split_dir):
                print(f"Warning: {split_dir} does not exist; trying the root directory")
                split_dir = self.root_dir
            split_dirs = [split_dir]

        # iterate over all split directories
        for split_dir in split_dirs:
            if not os.path.isdir(split_dir):
                continue

            # iterate over PlantDoc class folders
            for doc_class in sorted(os.listdir(split_dir)):
                doc_class_path = os.path.join(split_dir, doc_class)
                if not os.path.isdir(doc_class_path):
                    continue

                # try to map to PlantVillage classes
                pv_class = PLANTDOC_TO_PLANTVILLAGE_MAP.get(doc_class)
                if pv_class is None:
                    print(f"  [Skip] unmappable class: {doc_class}")
                    continue

                if pv_class not in self.pv_class_to_idx:
                    print(f"  [Skip] not present in PlantVillage: {pv_class}")
                    continue

                pv_idx = self.pv_class_to_idx[pv_class]

                # load the images of this class
                valid_images = 0
                skipped_images = 0

                for img_name in os.listdir(doc_class_path):
                    if not img_name.lower().endswith(('.jpg', '.jpeg', '.png', '.bmp')):
                        continue

                    img_path = os.path.join(doc_class_path, img_name)

                    # image integrity check
                    try:
                        with Image.open(img_path) as img:
                            img.verify()

                        # reopen to confirm readability
                        with Image.open(img_path) as img:
                            img.convert('RGB')

                        samples.append((img_path, pv_idx))
                        valid_images += 1

                    except Exception as e:
                        skipped_images += 1

                if valid_images > 0:
                    print(f"  {doc_class} -> {pv_class}: {valid_images}  ")
                if skipped_images > 0:
                    print(f"    (skipped corrupted images: {skipped_images})")

        return samples

    def pv_class_to_idx_inv(self, idx):
        """Reverse-lookup the class name."""
        for cls, i in self.pv_class_to_idx.items():
            if i == idx:
                return cls
        return "Unknown"

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        img_path, label = self.samples[idx]
        try:
            image = Image.open(img_path).convert('RGB')
        except Exception as e:
            print(f"Warning: failed to load image {img_path}: {e}")
            image = Image.new('RGB', (224, 224), (128, 128, 128))
        if self.transform:
            image = self.transform(image)
        return image, label


# ========== DANN components ==========
class GradientReversalLayer(torch.autograd.Function):
    @staticmethod
    def forward(ctx, x, alpha):
        ctx.alpha = alpha
        return x.view_as(x)

    @staticmethod
    def backward(ctx, grad_output):
        return grad_output.neg() * ctx.alpha, None


class DomainDiscriminator(nn.Module):
    def __init__(self, input_dim=1280, hidden_dim=256):
        super().__init__()
        self.network = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(0.5),
            nn.Linear(hidden_dim, 1)
        )

    def forward(self, x):
        return self.network(x)


class DANNModel(nn.Module):
    def __init__(self, base_model, num_classes=38):
        super().__init__()
        self.alpha = 0.0

        # obtain the feature extractor
        if hasattr(base_model, 'classifier'):
            self.feature_dim = base_model.classifier[1].in_features
            base_model.classifier = nn.Identity()
        else:
            self.feature_dim = 1280

        self.feature_extractor = base_model
        self.classifier = nn.Linear(self.feature_dim, num_classes)
        self.domain_discriminator = DomainDiscriminator(self.feature_dim)

    def forward(self, x, mode='feature'):
        features = self.feature_extractor(x)

        if mode == 'feature':
            return features
        elif mode == 'class':
            return self.classifier(features)
        elif mode == 'domain':
            reversed_features = GradientReversalLayer.apply(features, self.alpha)
            return self.domain_discriminator(reversed_features).squeeze()
        else:
            raise ValueError(f"Unknown mode: {mode}")


# ========== training function ==========
def train_epoch_dann(model, source_loader, target_loader, 
                     criterion_label, criterion_domain, optimizer, device):
    model.train()

    total_label_loss = 0
    total_domain_loss = 0
    total_correct = 0
    total_samples = 0

    source_iter = iter(source_loader)
    target_iter = iter(target_loader)

    num_batches = min(len(source_loader), len(target_loader))
    pbar = tqdm(range(num_batches), desc='DANN Train', leave=False)

    for _ in pbar:
        try:
            source_data, source_labels = next(source_iter)
        except StopIteration:
            source_iter = iter(source_loader)
            source_data, source_labels = next(source_iter)

        try:
            target_data, _ = next(target_iter)
        except StopIteration:
            target_iter = iter(target_loader)
            target_data, _ = next(target_iter)

        source_data = source_data.to(device)
        source_labels = source_labels.to(device)
        target_data = target_data.to(device)

        batch_size_src = source_data.size(0)
        batch_size_tgt = target_data.size(0)

        # merge source and target batches
        combined_data = torch.cat([source_data, target_data], dim=0)

        # domain labels
        domain_labels = torch.cat([
            torch.zeros(batch_size_src),
            torch.ones(batch_size_tgt)
        ]).to(device)

        optimizer.zero_grad()

        # feature extraction (single forward pass, avoiding redundancy)
        features = model(combined_data, mode='feature')

        # classification loss (source domain only)
        class_outputs = model.classifier(features[:batch_size_src])
        label_loss = criterion_label(class_outputs, source_labels)

        # domain-discrimination loss (GRL applied manually; no second forward pass)
        reversed_features = GradientReversalLayer.apply(features, model.alpha)
        domain_outputs = model.domain_discriminator(reversed_features).squeeze()
        domain_loss = criterion_domain(domain_outputs, domain_labels)

        # total loss
        total_loss = label_loss + 0.5 * domain_loss

        total_loss.backward()
        optimizer.step()

        total_label_loss += label_loss.item()
        total_domain_loss += domain_loss.item()

        _, predicted = class_outputs.max(1)
        total_correct += predicted.eq(source_labels).sum().item()
        total_samples += batch_size_src

        pbar.set_postfix({
            'label': f'{label_loss.item():.3f}',
            'domain': f'{domain_loss.item():.3f}',
            'acc': f'{100.*total_correct/total_samples:.1f}%'
        })

    return (total_label_loss / num_batches, 
            total_domain_loss / num_batches, 
            100. * total_correct / total_samples)


@torch.no_grad()
def evaluate(model, loader, criterion, device):
    model.eval()
    total_loss, correct, total = 0, 0, 0

    # use isinstance to distinguish the DANN model from a plain model
    is_dann = isinstance(model, DANNModel)

    for inputs, labels in tqdm(loader, desc='Eval', leave=False):
        inputs, labels = inputs.to(device), labels.to(device)

        if is_dann:
            # DANN model: extract features first, then apply the classifier
            features = model(inputs, mode='feature')
            outputs = model.classifier(features)
        else:
            # plain model: direct forward pass
            outputs = model(inputs)

        loss = criterion(outputs, labels)
        total_loss += loss.item() * inputs.size(0)

        _, predicted = outputs.max(1)
        correct += predicted.eq(labels).sum().item()
        total += labels.size(0)

    return total_loss / total, 100. * correct / total


# ========== Source-Only experiment (with checkpoint resume) ==========
def run_source_only(seed, save_dir):
    set_seed(seed)

    exp_tag = f"source_only_seed{seed}"
    model_path = os.path.join(CHECKPOINT_DIR, f"{exp_tag}_best.pth")
    result_path = os.path.join(save_dir, f"{exp_tag}_results.json")
    checkpoint_path = os.path.join(CHECKPOINT_DIR, f"{exp_tag}_checkpoint.pth")

    if os.path.exists(result_path):
        print(f"[Skip] already done: {exp_tag}")
        with open(result_path, 'r') as f:
            return json.load(f)

    print(f"\n{'='*70}")
    print(f"Source Only | seed={seed}")
    print(f"{'='*70}")

    # data
    train_transform, val_transform = get_transforms('strong')

    # PlantVillage
    source_train = datasets.ImageFolder(
        os.path.join(DATA_DIR, 'train'), transform=train_transform)
    source_train_loader = DataLoader(source_train, batch_size=16, shuffle=True,
                                      num_workers=4, pin_memory=True)

    source_val = datasets.ImageFolder(
        os.path.join(DATA_DIR, 'val'), transform=val_transform)
    source_val_loader = DataLoader(source_val, batch_size=16, shuffle=False,
                                    num_workers=4, pin_memory=True)

    # PlantDoctest
    pv_classes = source_train.classes
    print(f"\nPlantVillage classes: {len(pv_classes)}")

    plantdoc_test = PlantDocDataset(PLANTDOC_DIR, pv_classes, 
                                    transform=val_transform, split='test')
    plantdoc_test_loader = DataLoader(plantdoc_test, batch_size=16, shuffle=False,
                                       num_workers=4, pin_memory=True)

    # model
    model = models.efficientnet_b0(weights='IMAGENET1K_V1')
    model.classifier[1] = nn.Linear(model.classifier[1].in_features, 38)
    model = model.to(DEVICE)

    criterion = nn.CrossEntropyLoss()
    optimizer = optim.AdamW(model.parameters(), lr=5e-5, weight_decay=1e-3)
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, mode='max', factor=0.5, patience=5)

    # checkpoint-resume state initialization
    start_epoch = 0
    best_val_acc = 0.0
    patience_counter = 0
    history = {'train_acc': [], 'val_acc': []}

    # try to resume from a checkpoint
    if os.path.exists(checkpoint_path):
        print(f"[resume] checkpoint found: {checkpoint_path}")
        checkpoint = torch.load(checkpoint_path, map_location=DEVICE)
        model.load_state_dict(checkpoint['model_state'])
        optimizer.load_state_dict(checkpoint['optimizer_state'])
        scheduler.load_state_dict(checkpoint['scheduler_state'])
        start_epoch = checkpoint['epoch'] + 1
        best_val_acc = checkpoint['best_val_acc']
        patience_counter = checkpoint['patience_counter']
        history = checkpoint['history']
        print(f"[resume] continuing from epoch {start_epoch}, current best val_acc: {best_val_acc:.2f}%")

    # train
    for epoch in range(start_epoch, 80):
        print(f"\nEpoch {epoch+1}/80")

        model.train()
        train_correct, train_total = 0, 0
        for inputs, labels in tqdm(source_train_loader, desc='Train', leave=False):
            inputs, labels = inputs.to(DEVICE), labels.to(DEVICE)
            optimizer.zero_grad()
            outputs = model(inputs)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()

            _, predicted = outputs.max(1)
            train_correct += predicted.eq(labels).sum().item()
            train_total += labels.size(0)

        train_acc = 100. * train_correct / train_total

        val_loss, val_acc = evaluate(model, source_val_loader, criterion, DEVICE)

        history['train_acc'].append(train_acc)
        history['val_acc'].append(val_acc)

        print(f"Train Acc: {train_acc:.2f}% | Val Acc: {val_acc:.2f}%")

        scheduler.step(val_acc)

        if val_acc > best_val_acc:
            best_val_acc = val_acc
            torch.save(model.state_dict(), model_path)
            patience_counter = 0
            print(f"  -> savebestmodel")
        else:
            patience_counter += 1

        # save checkpoint every epoch so an interrupted run can be resumed
        torch.save({
            'epoch': epoch,
            'model_state': model.state_dict(),
            'optimizer_state': optimizer.state_dict(),
            'scheduler_state': scheduler.state_dict(),
            'best_val_acc': best_val_acc,
            'patience_counter': patience_counter,
            'history': history,
        }, checkpoint_path)

        if patience_counter >= 7:
            print("early stopping triggered")
            break

    # test PlantDoc
    print(f"\ntest PlantDoc...")
    model.load_state_dict(torch.load(model_path, map_location=DEVICE))
    test_loss, test_acc = evaluate(model, plantdoc_test_loader, criterion, DEVICE)
    print(f"PlantDoc test accuracy: {test_acc:.2f}%")

    results = {
        'exp_type': 'source_only',
        'seed': seed,
        'best_val_acc': best_val_acc,
        'plantdoc_test_acc': test_acc,
        'history': history,
        'epochs': len(history['train_acc'])
    }

    with open(result_path, 'w') as f:
        json.dump(results, f, indent=2)

    # training finished; clean up the checkpoint
    if os.path.exists(checkpoint_path):
        os.remove(checkpoint_path)
        print(f"Checkpoint file removed: {checkpoint_path}")

    return results


# ========== DANN experiment (with checkpoint resume) ==========
def run_dann(seed, save_dir):
    set_seed(seed)

    exp_tag = f"dann_seed{seed}"
    model_path = os.path.join(CHECKPOINT_DIR, f"{exp_tag}_best.pth")
    result_path = os.path.join(save_dir, f"{exp_tag}_results.json")
    checkpoint_path = os.path.join(CHECKPOINT_DIR, f"{exp_tag}_checkpoint.pth")

    if os.path.exists(result_path):
        print(f"[Skip] already done: {exp_tag}")
        with open(result_path, 'r') as f:
            return json.load(f)

    print(f"\n{'='*70}")
    print(f"DANN | seed={seed}")
    print(f"{'='*70}")

    # data
    train_transform, val_transform = get_transforms('strong')

    # PlantVillage source domain
    source_train = datasets.ImageFolder(
        os.path.join(DATA_DIR, 'train'), transform=train_transform)
    source_train_loader = DataLoader(source_train, batch_size=8, shuffle=True,
                                      num_workers=4, pin_memory=True, drop_last=True)

    source_val = datasets.ImageFolder(
        os.path.join(DATA_DIR, 'val'), transform=val_transform)
    source_val_loader = DataLoader(source_val, batch_size=16, shuffle=False,
                                    num_workers=4, pin_memory=True)

    # PlantVillageclasses
    pv_classes = source_train.classes
    print(f"\nPlantVillage classes: {len(pv_classes)}")

    # PlantDoc target domain (unlabeled)
    plantdoc_train = PlantDocDataset(PLANTDOC_DIR, pv_classes,
                                     transform=train_transform, split='train')
    # if train is empty, use all images
    if len(plantdoc_train) == 0:
        print("PlantDoc train is empty; using all data as the target domain")
        plantdoc_train = PlantDocDataset(PLANTDOC_DIR, pv_classes,
                                         transform=train_transform, split='all')

    target_train_loader = DataLoader(plantdoc_train, batch_size=8, shuffle=True,
                                      num_workers=4, pin_memory=True, drop_last=True)

    # PlantDoctest
    plantdoc_test = PlantDocDataset(PLANTDOC_DIR, pv_classes,
                                    transform=val_transform, split='test')
    plantdoc_test_loader = DataLoader(plantdoc_test, batch_size=16, shuffle=False,
                                       num_workers=4, pin_memory=True)

    # DANN model
    base_model = models.efficientnet_b0(weights='IMAGENET1K_V1')
    dann_model = DANNModel(base_model, num_classes=38)
    dann_model = dann_model.to(DEVICE)

    criterion_label = nn.CrossEntropyLoss()
    criterion_domain = nn.BCEWithLogitsLoss()
    optimizer = optim.AdamW(dann_model.parameters(), lr=5e-5, weight_decay=1e-3)
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, mode='max', factor=0.5, patience=5)

    # checkpoint-resume state initialization
    start_epoch = 0
    best_val_acc = 0.0
    patience_counter = 0
    history = {'label_loss': [], 'domain_loss': [], 'train_acc': [], 'val_acc': [], 'alpha': []}

    # try to resume from a checkpoint
    if os.path.exists(checkpoint_path):
        print(f"[resume] checkpoint found: {checkpoint_path}")
        checkpoint = torch.load(checkpoint_path, map_location=DEVICE)
        dann_model.load_state_dict(checkpoint['model_state'])
        optimizer.load_state_dict(checkpoint['optimizer_state'])
        scheduler.load_state_dict(checkpoint['scheduler_state'])
        start_epoch = checkpoint['epoch'] + 1
        best_val_acc = checkpoint['best_val_acc']
        patience_counter = checkpoint['patience_counter']
        history = checkpoint['history']
        print(f"[resume] continuing from epoch {start_epoch}, current best val_acc: {best_val_acc:.2f}%")

    # train
    for epoch in range(start_epoch, 80):
        alpha = min(1.0, epoch / 80.0)
        dann_model.alpha = alpha

        print(f"\nEpoch {epoch+1}/80 | alpha={alpha:.3f}")

        label_loss, domain_loss, train_acc = train_epoch_dann(
            dann_model, source_train_loader, target_train_loader,
            criterion_label, criterion_domain, optimizer, DEVICE
        )

        val_loss, val_acc = evaluate(dann_model, source_val_loader, criterion_label, DEVICE)

        history['label_loss'].append(label_loss)
        history['domain_loss'].append(domain_loss)
        history['train_acc'].append(train_acc)
        history['val_acc'].append(val_acc)
        history['alpha'].append(alpha)

        print(f"Label: {label_loss:.4f} | Domain: {domain_loss:.4f}")
        print(f"Train: {train_acc:.2f}% | Val: {val_acc:.2f}%")

        scheduler.step(val_acc)

        if val_acc > best_val_acc:
            best_val_acc = val_acc
            torch.save(dann_model.state_dict(), model_path)
            patience_counter = 0
            print(f"  -> savebestmodel")
        else:
            patience_counter += 1

        # save checkpoint every epoch
        torch.save({
            'epoch': epoch,
            'model_state': dann_model.state_dict(),
            'optimizer_state': optimizer.state_dict(),
            'scheduler_state': scheduler.state_dict(),
            'best_val_acc': best_val_acc,
            'patience_counter': patience_counter,
            'history': history,
        }, checkpoint_path)

        if patience_counter >= 7:
            print("early stopping triggered")
            break

    # test PlantDoc
    print(f"\ntest PlantDoc...")
    dann_model.load_state_dict(torch.load(model_path, map_location=DEVICE))
    test_loss, test_acc = evaluate(dann_model, plantdoc_test_loader, criterion_label, DEVICE)
    print(f"PlantDoc test accuracy: {test_acc:.2f}%")

    results = {
        'exp_type': 'dann',
        'seed': seed,
        'best_val_acc': best_val_acc,
        'plantdoc_test_acc': test_acc,
        'history': history,
        'epochs': len(history['train_acc'])
    }

    with open(result_path, 'w') as f:
        json.dump(results, f, indent=2)

    # training finished; clean up the checkpoint
    if os.path.exists(checkpoint_path):
        os.remove(checkpoint_path)
        print(f"Checkpoint file removed: {checkpoint_path}")

    return results


# ========== main ==========
if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Cross-domain experiment')
    parser.add_argument('--mode', type=str, default='both',
                       choices=['source_only', 'dann', 'both'])
    parser.add_argument('--seed', type=int, default=None)
    args = parser.parse_args()

    seeds = [42, 123, 456] if args.seed is None else [args.seed]

    print(f"mode: {args.mode} | seed: {seeds}")

    all_results = []

    for seed in seeds:
        if args.mode in ['source_only', 'both']:
            result = run_source_only(seed, SAVE_DIR)
            all_results.append(result)

        if args.mode in ['dann', 'both']:
            result = run_dann(seed, SAVE_DIR)
            all_results.append(result)

    # summary
    print(f"\n{'='*70}")
    print("cross-domain experiment summary")
    print(f"{'='*70}")

    for exp_type in ['source_only', 'dann']:
        type_results = [r for r in all_results if r['exp_type'] == exp_type]
        if not type_results:
            continue

        accs = [r['plantdoc_test_acc'] for r in type_results]
        print(f"\n{exp_type.upper()}:")
        print(f"  PlantDocaccuracy: {np.mean(accs):.2f} ± {np.std(accs, ddof=1):.2f}%")
        print(f"  raw values: {[f'{a:.2f}' for a in accs]}")

    summary_path = os.path.join(SAVE_DIR, 'cross_domain_summary.json')
    with open(summary_path, 'w') as f:
        json.dump(all_results, f, indent=2)

    # indentation aligned within the if __name__ block
    print(f"\nsummary saved: {summary_path}")
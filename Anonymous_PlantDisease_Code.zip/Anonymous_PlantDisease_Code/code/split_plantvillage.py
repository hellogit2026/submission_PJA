#!/usr/bin/env python3
"""
Stratified split of the PlantVillage dataset
=====================================
Splits the 38 classes of images under color/ into a stratified 70:15:15
      train/, val/, test/ folders

Usage: 
    python split_plantvillage.py --src_dir /path/to/raw/color --dst_dir /path/to/output



"""

import os
import shutil
import argparse
import random
from pathlib import Path
from collections import defaultdict


def parse_args():
    parser = argparse.ArgumentParser(description='Stratified split of the PlantVillage dataset')
    parser.add_argument('--src_dir', type=str, default='./data/PlantVillage-Dataset-master/raw/color',
                        help='path to the color/ directory')
    parser.add_argument('--dst_dir', type=str, default='./data/plantvillage_split',
                        help='output directory for the split data')
    parser.add_argument('--train_ratio', type=float, default=0.70,
                        help='training set ratio (default 0.70)')
    parser.add_argument('--val_ratio', type=float, default=0.15,
                        help='validation set ratio (default 0.15)')
    parser.add_argument('--test_ratio', type=float, default=0.15,
                        help='test set ratio (default 0.15)')
    parser.add_argument('--seed', type=int, default=42,
                        help='random seed for reproducibility (default 42)')
    parser.add_argument('--dry_run', action='store_true',
                        help='print split statistics only; do not copy files')
    return parser.parse_args()


def collect_images(src_dir):
    """Collect all classes and their image files"""
    class_images = defaultdict(list)
    src_path = Path(src_dir)

    if not src_path.exists():
        raise FileNotFoundError(f"source directory does not exist: {src_dir}")

    # iterate over all class folders under color/
    for class_dir in sorted(src_path.iterdir()):
        if class_dir.is_dir():
            class_name = class_dir.name
            # collect all image files of this class
            for img_file in sorted(class_dir.iterdir()):
                if img_file.is_file() and img_file.suffix.lower() in ['.jpg', '.jpeg', '.png', '.bmp']:
                    class_images[class_name].append(img_file)

    return class_images


def stratified_split(class_images, train_ratio, val_ratio, test_ratio, seed):
    """Stratified split for each class"""
    random.seed(seed)

    splits = {
        'train': defaultdict(list),
        'val': defaultdict(list),
        'test': defaultdict(list)
    }

    split_stats = {}

    for class_name, images in sorted(class_images.items()):
        n_total = len(images)
        if n_total == 0:
            continue

        # shuffle with the RNG
        shuffled = images.copy()
        random.shuffle(shuffled)

        # compute the size of each split
        n_train = int(n_total * train_ratio)
        n_val = int(n_total * val_ratio)
        # test takes the remainder to avoid rounding error
        n_test = n_total - n_train - n_val

        # split
        train_imgs = shuffled[:n_train]
        val_imgs = shuffled[n_train:n_train + n_val]
        test_imgs = shuffled[n_train + n_val:]

        splits['train'][class_name] = train_imgs
        splits['val'][class_name] = val_imgs
        splits['test'][class_name] = test_imgs

        split_stats[class_name] = {
            'total': n_total,
            'train': len(train_imgs),
            'val': len(val_imgs),
            'test': len(test_imgs)
        }

    return splits, split_stats


def copy_files(splits, dst_dir, dry_run=False):
    """Copy the images to the target directory"""
    dst_path = Path(dst_dir)

    for split_name, class_dict in splits.items():
        for class_name, images in class_dict.items():
            # target path: dst_dir/split_name/class_name/
            target_dir = dst_path / split_name / class_name

            if not dry_run:
                target_dir.mkdir(parents=True, exist_ok=True)

            for img_file in images:
                dst_file = target_dir / img_file.name
                if not dry_run:
                    shutil.copy2(img_file, dst_file)
                else:
                    print(f"[DRY RUN] would copy: {img_file} -> {dst_file}")


def print_summary(split_stats, splits):
    """Print the split statistics."""
    print("\n" + "=" * 70)
    print("Stratified split of the PlantVillage results")
    print("=" * 70)

    # header
    print(f"{'class name':<45} {'total':>6} {'train set':>8} {'val set':>8} {'test set':>8}")
    print("-" * 70)

    total_all = 0
    total_train = 0
    total_val = 0
    total_test = 0

    for class_name, stats in sorted(split_stats.items()):
        print(f"{class_name:<45} {stats['total']:>6} {stats['train']:>8} {stats['val']:>8} {stats['test']:>8}")
        total_all += stats['total']
        total_train += stats['train']
        total_val += stats['val']
        total_test += stats['test']

    print("-" * 70)
    print(f"{'TOTAL':<45} {total_all:>6} {total_train:>8} {total_val:>8} {total_test:>8}")
    print("=" * 70)

    # ratios
    print(f"\nratios:")
    print(f"  train set: {total_train}/{total_all} = {total_train/total_all*100:.2f}%")
    print(f"  val set: {total_val}/{total_all} = {total_val/total_all*100:.2f}%")
    print(f"  test set: {total_test}/{total_all} = {total_test/total_all*100:.2f}%")
    print(f"\nnum classes: {len(split_stats)}")

    # class-set consistency across the splits
    train_classes = set(splits['train'].keys())
    val_classes = set(splits['val'].keys())
    test_classes = set(splits['test'].keys())

    if train_classes == val_classes == test_classes:
        print(f"[OK] class sets are consistent across splits: {len(train_classes)}  classes")
    else:
        print("[FAIL] Warning: class sets are inconsistent across splits!")
        print(f"  train set: {len(train_classes)} classes")
        print(f"  val set: {len(val_classes)} classes")
        print(f"  test set: {len(test_classes)} classes")


def main():
    args = parse_args()

    # ratios
    total_ratio = args.train_ratio + args.val_ratio + args.test_ratio
    if abs(total_ratio - 1.0) > 1e-6:
        raise ValueError(f"ratios must sum to 1.0, got {total_ratio}")

    print(f"source directory: {args.src_dir}")
    print(f"target directory: {args.dst_dir}")
    print(f"split ratio: train set {args.train_ratio:.0%} / val set {args.val_ratio:.0%} / test set {args.test_ratio:.0%}")
    print(f"random seed: {args.seed}")
    print(f"dry run: {args.dry_run}")

    # 1. collect images
    print("\n[1/4] collecting images...")
    class_images = collect_images(args.src_dir)
    print(f"      found {len(class_images)}  classes")

    # 2. stratified split
    print("[2/4] performing the stratified split...")
    splits, split_stats = stratified_split(
        class_images, 
        args.train_ratio, 
        args.val_ratio, 
        args.test_ratio, 
        args.seed
    )

    # 3. print statistics
    print("[3/4] split statistics:")
    print_summary(split_stats, splits)

    # 4. copy files
    if not args.dry_run:
        print("\n[4/4] copying files...")
        copy_files(splits, args.dst_dir, dry_run=False)
        print(f"\n[OK] split done! data saved to: {args.dst_dir}")
        print(f"  directory structure:")
        print(f"    {args.dst_dir}/")
        print(f"    ├── train/  ({sum(len(v) for v in splits['train'].values())} images)")
        print(f"    ├── val/    ({sum(len(v) for v in splits['val'].values())} images)")
        print(f"    └── test/   ({sum(len(v) for v in splits['test'].values())} images)")
    else:
        print("\n[4/4] copy skipped (dry-run mode)")

    print("\n" + "=" * 70)


if __name__ == '__main__':
    main()
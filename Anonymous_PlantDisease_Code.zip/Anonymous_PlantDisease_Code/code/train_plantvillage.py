#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
PlantVillage main experiment runner (with checkpoint resume)
3 models × 2 initializations × 2 augmentations = 12 configs × 6 seeds = 72 runs

Usage:
    1. run all 12 configs with a chosen seed:
       python train_plantvillage.py

    2. run a single cell (e.g. experiment 0, seed 42):
       python train_plantvillage.py 0 42

    3. checkpoint resume:
       simply rerun the script after an interruption to resume automatically
"""

import os
import json
import time
import random
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from torchvision import datasets, transforms, models
from torch.amp import autocast, GradScaler
from tqdm import tqdm

# ========== path configuration ==========
ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(ROOT_DIR, "data", "plantvillage_split")
SAVE_DIR = os.path.join(ROOT_DIR, "results", "main_experiment")
CHECKPOINT_DIR = os.path.join(ROOT_DIR, "checkpoints")
LOG_DIR = os.path.join(ROOT_DIR, "logs")
RESUME_PATH = os.path.join(CHECKPOINT_DIR, "resume_state_DISABLED.pt")

for d in [SAVE_DIR, CHECKPOINT_DIR, LOG_DIR]:
    os.makedirs(d, exist_ok=True)

DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f"Using device: {DEVICE}")
if DEVICE.type == 'cuda':
    print(f"GPU: {torch.cuda.get_device_name(0)}")
    print(f"GPU memory: {torch.cuda.get_device_properties(0).total_memory / 1024**3:.1f} GB")

# ========== global resume state ==========
resume_state = None  # loaded global checkpoint state


# ========== utility functions ==========
def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if DEVICE.type == 'cuda':
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def get_transforms(aug_type='baseline'):
    if aug_type == 'baseline':
        train_transform = transforms.Compose([
            transforms.Resize((256, 256)),
            transforms.RandomCrop(224, padding=4),
            transforms.RandomHorizontalFlip(p=0.5),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406],
                               std=[0.229, 0.224, 0.225])
        ])
    elif aug_type == 'strong':
        train_transform = transforms.Compose([
            transforms.Resize((256, 256)),
            transforms.RandomCrop(224, padding=4),
            transforms.RandomHorizontalFlip(p=0.5),
            transforms.ColorJitter(brightness=0.2, contrast=0.2,
                                 saturation=0.2, hue=0.05),
            transforms.RandomRotation(degrees=15),
            transforms.GaussianBlur(kernel_size=3, sigma=(0.1, 2.0)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406],
                               std=[0.229, 0.224, 0.225])
        ])
    else:
        raise ValueError(f"Unknown aug_type: {aug_type}")

    val_transform = transforms.Compose([
        transforms.Resize((256, 256)),
        transforms.CenterCrop(224),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406],
                           std=[0.229, 0.224, 0.225])
    ])
    return train_transform, val_transform


def get_data_loaders(data_dir, train_transform, val_transform, batch_size, num_workers=1):
    train_dir = os.path.join(data_dir, 'train')
    val_dir = os.path.join(data_dir, 'val')
    test_dir = os.path.join(data_dir, 'test')

    train_dataset = datasets.ImageFolder(train_dir, transform=train_transform)
    val_dataset = datasets.ImageFolder(val_dir, transform=val_transform)
    test_dataset = datasets.ImageFolder(test_dir, transform=val_transform)

    train_loader = DataLoader(train_dataset, batch_size=batch_size,
                             shuffle=True, num_workers=num_workers,
                             pin_memory=True, drop_last=True)
    val_loader = DataLoader(val_dataset, batch_size=batch_size,
                           shuffle=False, num_workers=num_workers,
                           pin_memory=True)
    test_loader = DataLoader(test_dataset, batch_size=batch_size,
                            shuffle=False, num_workers=num_workers,
                            pin_memory=True)
    return train_loader, val_loader, test_loader, train_dataset.classes


def get_model(model_name, num_classes, pretrained=False):
    weights = 'IMAGENET1K_V1' if pretrained else None
    if model_name == 'resnet50':
        model = models.resnet50(weights=weights)
        model.fc = nn.Linear(model.fc.in_features, num_classes)
    elif model_name == 'mobilenet_v2':
        model = models.mobilenet_v2(weights=weights)
        model.classifier[1] = nn.Linear(model.classifier[1].in_features, num_classes)
    elif model_name == 'efficientnet_b0':
        model = models.efficientnet_b0(weights=weights)
        model.classifier[1] = nn.Linear(model.classifier[1].in_features, num_classes)
    else:
        raise ValueError(f"Unknown model: {model_name}")
    return model


def train_epoch(model, loader, criterion, optimizer, device, scaler=None):
    model.train()
    total_loss, correct, total = 0, 0, 0
    pbar = tqdm(loader, desc='Training')
    for inputs, labels in pbar:
        inputs, labels = inputs.to(device), labels.to(device)
        optimizer.zero_grad()
        if scaler is not None:
            with autocast(device_type="cuda"):
                outputs = model(inputs)
                loss = criterion(outputs, labels)
            scaler.scale(loss).backward()
            scaler.step(optimizer)
            scaler.update()
        else:
            outputs = model(inputs)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()
        total_loss += loss.item() * inputs.size(0)
        _, predicted = outputs.max(1)
        correct += predicted.eq(labels).sum().item()
        total += labels.size(0)
        pbar.set_postfix({
            'loss': f'{loss.item():.4f}',
            'acc': f'{100.*correct/total:.2f}%'
        })
    return total_loss / total, 100. * correct / total


@torch.no_grad()
def evaluate(model, loader, criterion, device):
    model.eval()
    total_loss, correct, total = 0, 0, 0
    for inputs, labels in tqdm(loader, desc='Evaluating'):
        inputs, labels = inputs.to(device), labels.to(device)
        outputs = model(inputs)
        loss = criterion(outputs, labels)
        total_loss += loss.item() * inputs.size(0)
        _, predicted = outputs.max(1)
        correct += predicted.eq(labels).sum().item()
        total += labels.size(0)
    return total_loss / total, 100. * correct / total


class WarmupScheduler:
    def __init__(self, optimizer, warmup_epochs, base_scheduler):
        self.optimizer = optimizer
        self.warmup_epochs = warmup_epochs
        self.base_scheduler = base_scheduler
        self.base_lr = optimizer.param_groups[0]['lr']
        self.current_epoch = 0

    def step(self, metric=None):
        self.current_epoch += 1
        if self.current_epoch <= self.warmup_epochs:
            warmup_factor = self.current_epoch / self.warmup_epochs
            for param_group in self.optimizer.param_groups:
                param_group['lr'] = self.base_lr * warmup_factor
        else:
            if self.base_scheduler is not None:
                if metric is not None:
                    self.base_scheduler.step(metric)
                else:
                    self.base_scheduler.step()

    def state_dict(self):
        return {
            'current_epoch': self.current_epoch,
            'base_scheduler': self.base_scheduler.state_dict() if self.base_scheduler else None
        }

    def load_state_dict(self, state_dict):
        self.current_epoch = state_dict['current_epoch']
        if self.base_scheduler and state_dict['base_scheduler']:
            self.base_scheduler.load_state_dict(state_dict['base_scheduler'])


# ========== checkpoint-resume core functions ==========
def save_resume_state(exp_cfg, epoch, model, optimizer, scheduler, scaler,
                      best_acc, history, epochs_no_improve, elapsed_time):
    """Save the global checkpoint state."""
    state = {
        'exp_cfg': exp_cfg,
        'epoch': epoch,
        'best_acc': best_acc,
        'epochs_no_improve': epochs_no_improve,
        'model_state_dict': model.state_dict(),
        'optimizer_state_dict': optimizer.state_dict(),
        'scheduler_state_dict': scheduler.state_dict(),
        'scaler_state_dict': scaler.state_dict() if scaler else None,
        'history': history,
        'elapsed_time': elapsed_time,
        'timestamp': time.time()
    }
    torch.save(state, os.path.join(CHECKPOINT_DIR, f"resume_{exp_cfg[0]}_{'pt' if exp_cfg[2] else 'ri'}_{exp_cfg[1]}_seed{exp_cfg[4]}.pt"))
    print(f"  [Checkpoint saved] epoch={epoch+1}, best_val_acc={best_acc:.2f}%")


def load_resume_state():
    import sys as _s
    _p = RESUME_PATH
    if len(_s.argv) > 2:
        _c = experiments[int(_s.argv[1])]
        _seed = int(_s.argv[2])
        _p = os.path.join(CHECKPOINT_DIR, f"resume_{_c[0]}_{'pt' if _c[2] else 'ri'}_{_c[1]}_seed{_seed}.pt")
    print(f"[Patch] per-task resume file: {_p}")
    """Load the global checkpoint state."""
    global resume_state
    if os.path.exists(_p):
        resume_state = torch.load(_p, map_location=DEVICE)
        cfg = resume_state['exp_cfg']
        print(f"\n{'='*70}")
        print(f"[checkpointresume] Unfinished experiment detected:")
        print(f"  model: {cfg[0]}, augmentation: {cfg[1]}, pretrained: {cfg[2]}, seed: {cfg[4]}")
        print(f"  interrupted at epoch: {resume_state['epoch']+1}")
        print(f"  previous best: {resume_state['best_acc']:.2f}%")
        print(f"{'='*70}")
        return True
    return False


def clear_resume_state():
    """Clear the checkpoint (called after an experiment finishes)."""
    global resume_state
    if os.path.exists(RESUME_PATH):
        os.remove(RESUME_PATH)
        print("  [checkpoint cleared]")
    resume_state = None


# ========== main training function ==========
def run_experiment(model_name, aug_type, pretrained=False, seed=42,
                   epochs=80, batch_size=16, lr=None, patience=7, warmup_epochs=10):
    global resume_state

    # set the learning rate automatically
    if lr is None:
        lr = 5e-5 if pretrained else 1e-3

    exp_cfg = (model_name, aug_type, pretrained, batch_size, seed)
    exp_tag = f"{model_name}_{'pt' if pretrained else 'ri'}_{aug_type}_seed{seed}"
    model_path = os.path.join(CHECKPOINT_DIR, f"{exp_tag}_best.pth")

    # skip if results for this experiment already exist
    result_path = os.path.join(SAVE_DIR, f"{exp_tag}_history.json")
    if os.path.exists(result_path):
        print(f"\n[Skip] experiment already done: {exp_tag}")
        with open(result_path, 'r') as f:
            return json.load(f)

    # check whether this is the experiment to resume
    is_resuming = False
    start_epoch = 0
    elapsed_time = 0
    if resume_state is not None:
        saved_cfg = resume_state['exp_cfg']
        if (saved_cfg[0] == model_name and saved_cfg[1] == aug_type and
            saved_cfg[2] == pretrained and saved_cfg[4] == seed):
            is_resuming = True
            start_epoch = resume_state['epoch'] + 1
            elapsed_time = resume_state.get('elapsed_time', 0)
            print(f"\n[resume] continuing from epoch {start_epoch}")

    # set the random seed
    set_seed(seed)

    print(f"\n{'='*70}")
    init_type = "ImageNet pretraining" if pretrained else "random initialization"
    print(f"experiment: {model_name} + {aug_type} + {init_type}")
    print(f"seed={seed}, lr={lr}, batch_size={batch_size}")
    if is_resuming:
        print(f"[resume] continuing from epoch {start_epoch}")
    print(f"{'='*70}")

    # dataload
    train_transform, val_transform = get_transforms(aug_type)
    train_loader, val_loader, test_loader, classes = get_data_loaders(
        DATA_DIR, train_transform, val_transform, batch_size, num_workers=1
    )
    num_classes = len(classes)
    print(f"num classes: {num_classes}, train samples: {len(train_loader.dataset)}")

    # model
    model = get_model(model_name, num_classes, pretrained=pretrained)
    model = model.to(DEVICE)

    total_params = sum(p.numel() for p in model.parameters())
    trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"total params: {total_params:,} ({total_params/1e6:.2f}M)")
    print(f"trainable params: {trainable_params:,} ({trainable_params/1e6:.2f}M)")

    # optimizer
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.AdamW(model.parameters(), lr=lr, weight_decay=1e-3)
    base_scheduler = optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, mode='max', factor=0.5, patience=5
    )
    scheduler = WarmupScheduler(optimizer, warmup_epochs, base_scheduler)
    scaler = GradScaler("cuda") if DEVICE.type == 'cuda' else None

    # initialize the history record
    if is_resuming:
        model.load_state_dict(resume_state['model_state_dict'])
        optimizer.load_state_dict(resume_state['optimizer_state_dict'])
        scheduler.load_state_dict(resume_state['scheduler_state_dict'])
        if scaler and resume_state['scaler_state_dict']:
            scaler.load_state_dict(resume_state['scaler_state_dict'])
        history = resume_state['history']
        best_acc = resume_state['best_acc']
        epochs_no_improve = resume_state['epochs_no_improve']
        print(f"[resume state] best_acc={best_acc:.2f}%, epochs_no_improve={epochs_no_improve}")
    else:
        history = {
            'model': model_name, 'aug_type': aug_type, 'pretrained': pretrained,
            'seed': seed, 'lr': lr, 'weight_decay': 1e-3, 'batch_size': batch_size,
            'warmup_epochs': warmup_epochs,
            'train_loss': [], 'train_acc': [],
            'val_loss': [], 'val_acc': [],
            'epochs': [], 'learning_rates': []
        }
        best_acc = 0.0
        epochs_no_improve = 0

    start_time = time.time()

    # training loop
    for epoch in range(start_epoch, epochs):
        print(f"\nEpoch {epoch+1}/{epochs}")
        train_loss, train_acc = train_epoch(
            model, train_loader, criterion, optimizer, DEVICE, scaler
        )
        val_loss, val_acc = evaluate(model, val_loader, criterion, DEVICE)
        current_lr = optimizer.param_groups[0]['lr']

        history['epochs'].append(epoch + 1)
        history['train_loss'].append(train_loss)
        history['train_acc'].append(train_acc)
        history['val_loss'].append(val_loss)
        history['val_acc'].append(val_acc)
        history['learning_rates'].append(current_lr)

        print(f"Train Loss: {train_loss:.4f}, Train Acc: {train_acc:.2f}%")
        print(f"Val Loss: {val_loss:.4f}, Val Acc: {val_acc:.2f}%")
        print(f"LR: {current_lr:.6f}")

        scheduler.step(val_acc)

        # savebestmodel
        if val_acc > best_acc:
            best_acc = val_acc
            torch.save({
                'epoch': epoch,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'val_acc': val_acc,
                'classes': classes
            }, model_path)
            print(f"  -> savebestmodel (Val Acc: {best_acc:.2f}%)")
            epochs_no_improve = 0
        else:
            epochs_no_improve += 1

        # save checkpoint every epoch (against interruption)
        current_elapsed = elapsed_time + (time.time() - start_time)
        save_resume_state(exp_cfg, epoch, model, optimizer, scheduler, scaler,
                          best_acc, history, epochs_no_improve, current_elapsed)

        # early-stopping check
        if epochs_no_improve >= patience:
            print(f"\nearly stopping triggered: no val-accuracy improvement for {patience} epochs")
            break

    total_elapsed = elapsed_time + (time.time() - start_time)

    print(f"\ntraining done! total time: {total_elapsed/3600:.2f} h")
    print(f"bestvalaccuracy: {best_acc:.2f}%")

    # evaluate on the test set
    print(f"\nevaluating the best model on the test set ...")
    checkpoint = torch.load(model_path, map_location=DEVICE)
    model.load_state_dict(checkpoint['model_state_dict'])
    test_loss, test_acc = evaluate(model, test_loader, criterion, DEVICE)
    print(f"Test accuracy: {test_acc:.2f}%")

    # fill in the history record
    history['test_acc'] = test_acc
    history['best_val_acc'] = best_acc
    history['best_epoch'] = epoch + 1
    history['total_time'] = total_elapsed
    history['total_params'] = total_params
    history['trainable_params'] = trainable_params
    history['completed'] = True
    history['elapsed_time'] = total_elapsed

    # save the results
    with open(result_path, 'w') as f:
        json.dump(history, f, indent=2)
    print(f"Results saved: {result_path}")

    # clear the checkpoint
    clear_resume_state()

    return history


# ========== main ==========
if __name__ == '__main__':
    import sys

    # experiment config: (model, augmentation type, pretrained, batch_size)
    experiments = [
        ('resnet50', 'baseline', True, 12),
        ('resnet50', 'strong', True, 12),
        ('mobilenet_v2', 'baseline', True, 32),
        ('mobilenet_v2', 'strong', True, 32),
        ('efficientnet_b0', 'baseline', True, 16),
        ('efficientnet_b0', 'strong', True, 16),
        ('resnet50', 'baseline', False, 12),
        ('resnet50', 'strong', False, 12),
        ('mobilenet_v2', 'baseline', False, 32),
        ('mobilenet_v2', 'strong', False, 32),
        ('efficientnet_b0', 'baseline', False, 16),
        ('efficientnet_b0', 'strong', False, 16),
    ]

    seeds = [42, 123, 456]

    # load the checkpoint if present
    has_resume = load_resume_state()

    # if an experiment index is given on the command line, run only that cell
    if len(sys.argv) > 1:
        exp_idx = int(sys.argv[1])
        seeds = [int(sys.argv[2])] if len(sys.argv) > 2 else [42]
        experiments = [experiments[exp_idx]]

    all_results = []
    skipped = 0

    for seed in seeds:
        for cfg in experiments:
            model_name, aug_type, pretrained, batch_size = cfg

            # check whether results already exist
            exp_tag = f"{model_name}_{'pt' if pretrained else 'ri'}_{aug_type}_seed{seed}"
            result_path = os.path.join(SAVE_DIR, f"{exp_tag}_history.json")
            if os.path.exists(result_path):
                print(f"[Skip] already exists: {exp_tag}")
                with open(result_path, 'r') as f:
                    all_results.append(json.load(f))
                skipped += 1
                continue

            # check whether this is the experiment the checkpoint wants to resume
            if has_resume and resume_state is not None:
                saved_cfg = resume_state['exp_cfg']
                if not (saved_cfg[0] == model_name and saved_cfg[1] == aug_type and
                        saved_cfg[2] == pretrained and saved_cfg[4] == seed):
                    print(f"[Skip] waiting for resumable experiment: {exp_tag}")
                    continue

            try:
                if DEVICE.type == 'cuda':
                    torch.cuda.empty_cache()

                history = run_experiment(
                    model_name=model_name,
                    aug_type=aug_type,
                    pretrained=pretrained,
                    seed=seed,
                    epochs=80,
                    batch_size=batch_size,
                    patience=7,
                    warmup_epochs=10
                )
                all_results.append(history)

            except Exception as e:
                print(f"\n[Error] Experiment failed: {model_name} + {aug_type} + seed={seed}")
                print(f"Error: {str(e)}")
                import traceback
                traceback.print_exc()
                continue

    # savesummary
    summary_path = os.path.join(SAVE_DIR, 'all_results_summary.json')
    with open(summary_path, 'w') as f:
        json.dump(all_results, f, indent=2)

    print(f"\n{'='*70}")
    print("Batch finished!")
    print(f"{'='*70}")
    print(f"total: {len(all_results)} experiments (skipped {skipped} already done)")
    print(f"\n{'model':<20} {'init':<10} {'augmentation':<10} {'seed':<8} {'testAcc':<10} {'time(h)':<10}")
    print("-" * 80)
    for r in all_results:
        init = 'PT' if r['pretrained'] else 'RI'
        print(f"{r['model']:<20} {init:<10} {r['aug_type']:<10} {r['seed']:<8} "
              f"{r['test_acc']:<10.2f} {r['total_time']/3600:<10.2f}")

    # warn if an unresumed checkpoint remains
    if os.path.exists(RESUME_PATH):
        print(f"\n{'!'*70}")
        print("[Warning] unresumed checkpoint remains; rerun the script to continue")
        print(f"checkpointfile: {RESUME_PATH}")
        print(f"{'!'*70}")
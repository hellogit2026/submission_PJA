# Anonymous Code & Results for: CNN-Based Plant Disease Identification

This repository contains the source code and complete per-run result JSONs for our study. Trained model weights are not included due to size; they will be released upon acceptance.

## 1. Environment Setup
We recommend Python 3.10+ and PyTorch 2.x. All experiments were run on an NVIDIA T4 GPU (16 GB); training the full factorial takes approximately 150 GPU-hours.

    pip install -r requirements.txt

## 2. Dataset Preparation
Datasets are not included.

**PlantVillage**: put the raw dataset in `data/plantvillage_raw/`, then run:

    python code/split_plantvillage.py --src_dir data/plantvillage_raw/color --dst_dir data/plantvillage_split --train_ratio 0.7 --val_ratio 0.15 --test_ratio 0.15 --seed 42

This reproduces the 70/15/15 stratified split used in the paper; all training scripts read from `data/plantvillage_split/{train,val,test}`.

**PlantDoc**: put both `train/` and `test/` splits in `data/plantdoc_raw/`. The cleaning procedure follows Appendix D of the manuscript; the class mapping is hardcoded in `code/cross_domain_inference.py`.

## 3. Running the Experiments

**Main factorial experiment** (12 configs × 6 seeds). The script takes positional
arguments `EXP_IDX` (0-11, selecting one row of the `experiments` list at line ~446
of `train_plantvillage.py`) and `SEED` (one of 42, 123, 456, 7, 77, 777):

    # single cell, e.g. ResNet50+PT+Basic at seed 42:
    python code/train_plantvillage.py 0 42

    # full factorial (72 runs):
    for i in $(seq 0 11); do for s in 42 123 456 7 77 777; do python code/train_plantvillage.py $i $s; done; done

**Ablation experiments** (Groups A–F):

    python code/train_ablation.py --group A
    # single cell: python code/train_ablation.py --exp D1

**Cross-domain evaluation** (requires a trained checkpoint, which will be released upon acceptance; any of the 72 main-experiment runs produces one):

    python code/cross_domain_inference.py --exp-type source_only --seed 42 --model-path CKPT_PATH
    python code/cross_domain_experiment.py --seed 42    # DANN training

**Recomputing summary statistics** (Tables 1 and 4) and figures:

    python code/final_stats.py
    python code/plot_figB3.py

## 4. Notes on Code Implementation
- **Checkpoint loading**: the inference code accepts both full training checkpoints (with optimizer state) and model-only state dicts.
- **Shared ablation baseline**: A2/B2/C2/D2/E1/F3 refer to one control run (seed 42), reported once in `results/ablation_experiment/`.
- **B1***: the controlled run (random initialization at the fixed lr = 5e-5) is stored as `B1s_*`; B3, D1, and F1 were repeated with seeds 42/123/456 (three-seed means in Table 4); exploratory seeds 2024/9999 are excluded from the balanced design (manuscript Section 2.3).
- **Legacy scripts**: `code/legacy/` contains protocol-development scripts (e.g., the exploratory MobileNetV2 seed-extension experiment); they are not part of the released pipeline and are provided for completeness only.
- **Wall-clock time**: `total_time` in the main-experiment JSONs reflects concurrent multi-job training; convergence epochs are the meaningful efficiency metric.

## 5. Released Per-run JSONs

| Folder | Contents | Used for |
|---|---|---|
| `results/main_experiment/` | 77 history JSONs (12 configs × 6 seeds, plus 5 exploratory runs with seeds 2024/9999 excluded from statistics) + summary files | Table 1, Figure 1, Table 3 |
| `results/ablation_experiment/` | single-run cells + B1s + three-seed B3/D1/F1 | Table 4 |
| `results/cross_domain/` | 9 condition×seed summary JSONs + `cross_domain_summary.json` | Table 6 |
| `results/cross_domain_detailed/` | per-seed `class_metrics.json`, `confusion_matrix.json`, `sample_predictions.json`, `summary.json` | Table 7, Table B3, Figures B1–B3 |

Each history JSON contains `test_acc`, `best_val_acc`, `best_epoch`, per-epoch `train_loss` / `train_acc` / `val_loss` / `val_acc`, the `learning_rates` trajectory, and the full configuration.

## 6. Note on `learning_rates` in JSONs
The `learning_rates` array logs the LR in effect at the end of each epoch:
- element 0 = the base learning rate before warm-up starts (e.g. `5e-5`);
- element 1 = the first warm-up step (`base_lr × 1/10`, e.g. `5e-6`);
- it ramps linearly to the base LR at epoch 10, after which the `ReduceLROnPlateau` schedule (factor 0.5, patience 5) takes over.

A naive diff of consecutive elements therefore shows a "drop" between elements 0 and 1; this is the warm-up convention, not an early LR reduction.
